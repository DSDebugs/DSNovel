// DSNovel 听书专享优化版公共辅助库 (common.js v5.6.4)
var Shun = (function () {
  var AUDIO_EXTS = ['.m4a', '.mp3', '.m4b', '.flac', '.aa3', '.ogg', '.wma', '.wav', '.aac', '.ac3', '.mp4'];
  var XMLY_KEY = 'aaad3e4fd540b0f79dca95606e72bf93';
  var TINGYOU_SITE = 'https://tingyou.fm';
  var TINGYOU_BASES = [
    'https://api-preview.toulaopao.cc/api',
    'https://appp.fdhtbz.cn/api',
    'https://laopaoaappi.oobyvy.vip/api'
  ];
  var YUNTU_HOST = 'open-service.yuntuys.com/api/w_ys/book/';
  var YUNTU_TOKEN = 'wechat:07955551-706c-4259-9aa0-db4627dfca57';

  var workingTingyouBase = null;
  var tingyouSession = null;
  var workingYuntuProto = null;

  var none = {
    exists: function () { return false; },
    text: function () { return ''; },
    ownText: function () { return ''; },
    attr: function () { return ''; },
    absUrl: function () { return ''; },
    first: function () { return none; },
    select: function () { return []; }
  };

  function httpsUrl(u) {
    if (!u) return '';
    var s = String(u).trim();
    if (!s || /^data:/i.test(s)) return '';
    if (s.indexOf('//') === 0) return 'https:' + s;
    return s.replace(/^http:\/\//i, 'https://');
  }

  function cleanHtml(raw) {
    if (!raw) return '';
    return String(raw)
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/p\s*>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/[ \t\r]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function stripIntroPrefix(raw) {
    return cleanHtml(raw)
      .replace(/^(?:内容简介|剧情简介|作品简介|故事简介|专辑简介|简介)\s*[：:]\s*/i, '')
      .trim();
  }

  function discoverTingyouBase(host) {
    try {
      var m = /https:\/\/[a-z0-9.-]+\/api(?=["\\/])/i.exec(host.getString(TINGYOU_SITE + '/listening'));
      return m ? m[0] : null;
    } catch (e) {
      if (e && e.cancelled) throw e;
      return null;
    }
  }

  function ensureTingyouSession(host) {
    if (tingyouSession) return tingyouSession;
    var saved = (typeof host.getPref === 'function') ? host.getPref('tingyou_session') : null;
    if (saved) {
      tingyouSession = String(saved);
      return tingyouSession;
    }
    tingyouSession = (typeof host.uuid === 'function') ? host.uuid() : 'dsnovel-ty-session';
    if (typeof host.setPref === 'function') host.setPref('tingyou_session', tingyouSession);
    return tingyouSession;
  }

  function callTingyou(host, path, body, allowEmpty) {
    ensureTingyouSession(host);
    var savedBase = (typeof host.getPref === 'function') ? host.getPref('tingyou_base') || host.getPref('base') : null;
    var list = [workingTingyouBase, savedBase].concat(TINGYOU_BASES);
    var tried = {}, last = null;
    for (var i = 0; i <= list.length; i++) {
      var base = i < list.length ? list[i] : discoverTingyouBase(host);
      if (!base || tried[base]) continue;
      tried[base] = true;
      try {
        var opts = {
          headers: {
            Origin: TINGYOU_SITE,
            Referer: TINGYOU_SITE + '/',
            Accept: 'application/json',
            'x-listening-session': tingyouSession,
            'x-listening-timezone': 'Asia/Shanghai'
          }
        };
        if (body !== undefined) {
          opts.method = 'POST';
          opts.body = JSON.stringify(body);
          opts.contentType = 'application/json';
        }
        var text = host.getString(base + '/h5/listening/' + path, opts);
        if (!String(text || '').trim() && allowEmpty) return {};
        var json = parseJson(text);
        if (json && json.error) throw new Error(str(json, 'message') || '接口返回错误');
        if (workingTingyouBase !== base) {
          workingTingyouBase = base;
          if (typeof host.setPref === 'function') host.setPref('tingyou_base', base);
        }
        return json;
      } catch (e) {
        if (e && e.cancelled) throw e;
        last = e;
      }
    }
    throw new Error('听友听书接口暂时无法访问：' + (last ? last.message : '无可用网关'));
  }

  function tingyouBaseUrl(host) {
    if (workingTingyouBase) return workingTingyouBase;
    var saved = (typeof host.getPref === 'function') ? host.getPref('tingyou_base') || host.getPref('base') : null;
    return saved || TINGYOU_BASES[0];
  }

  function tingyouHeaders(host) {
    ensureTingyouSession(host);
    return {
      Origin: TINGYOU_SITE,
      Referer: TINGYOU_SITE + '/',
      Accept: 'application/json',
      'x-listening-session': tingyouSession,
      'x-listening-timezone': 'Asia/Shanghai'
    };
  }

  function yuntuUrl(proto, subPath) {
    return proto + '://' + YUNTU_HOST + subPath;
  }

  function yuntuGetJson(host, subPath) {
    var savedProto = (typeof host.getPref === 'function') ? host.getPref('yuntu_proto') : null;
    var first = workingYuntuProto || savedProto || 'https';
    var order = first === 'http' ? ['http', 'https'] : ['https', 'http'];
    var lastErr = null;
    for (var i = 0; i < order.length; i++) {
      var proto = order[i];
      try {
        var json = host.getJson(yuntuUrl(proto, subPath));
        if (workingYuntuProto !== proto) {
          workingYuntuProto = proto;
          if (typeof host.setPref === 'function') host.setPref('yuntu_proto', proto);
        }
        return json;
      } catch (e) {
        if (e && e.cancelled) throw e;
        lastErr = e;
      }
    }
    throw lastErr || new Error('云图有声接口暂时无法访问');
  }

  function yuntuCurrentBase(host) {
    var savedProto = (typeof host.getPref === 'function') ? host.getPref('yuntu_proto') : null;
    var proto = workingYuntuProto || savedProto || 'https';
    return proto + '://' + YUNTU_HOST;
  }

  function resolveXimalayaAudio(host, trackId, quality) {
    var id = String(trackId || '').replace(/^(?:xm:|fq:\/\/xmly_track\/)/, '');
    var targetQuality = String(quality || 'M4A_128').toUpperCase();
    var priorityMap = {
      'M4A_24':  ['M4A_24', 'MP3_32', 'M4A_64', 'MP3_64', 'M4A_128'],
      'M4A_64':  ['M4A_64', 'MP3_64', 'M4A_24', 'MP3_32', 'M4A_128'],
      'M4A_128': ['M4A_128', 'M4A_64', 'MP3_64', 'MP3_32', 'M4A_24']
    };
    var order = priorityMap[targetQuality] || priorityMap['M4A_128'];

    var json = host.getJson('https://www.ximalaya.com/mobile-playpage/track/v3/baseInfo/' + Date.now() +
      '?device=web&trackId=' + id + '&trackQualityLevel=2', {
      desktop: true, headers: { Referer: 'https://www.ximalaya.com/' }
    });
    var list = items(json, 'trackInfo.playUrlList');

    if (list.length > 0) {
      var pick = null;
      for (var i = 0; i < order.length && !pick; i++) {
        for (var j = 0; j < list.length; j++) {
          if (str(list[j], 'type').toUpperCase() === order[i]) {
            pick = list[j];
            break;
          }
        }
      }
      if (!pick) pick = list[0];
      var audio = host.aesEcbDecrypt(str(pick, 'url'), XMLY_KEY);
      if (audio && audio.indexOf('http') === 0) return httpsUrl(audio);
    }

    try {
      var mobileInfo = host.getJson('https://mobile.ximalaya.com/mobile/playpage/track/v3/baseInfo/' + Date.now() + '?device=iPhone&trackId=' + id);
      var ti = at(mobileInfo, 'trackInfo') || {};
      var fallbackChain;
      if (targetQuality === 'M4A_24') {
        fallbackChain = str(ti, 'playPathAacv224') || str(ti, 'playUrl32') || str(ti, 'playPathAacv164') || str(ti, 'playUrl64');
      } else if (targetQuality === 'M4A_64') {
        fallbackChain = str(ti, 'playPathAacv164') || str(ti, 'playUrl64') || str(ti, 'playPathAacv224') || str(ti, 'playUrl32');
      } else {
        fallbackChain = str(ti, 'playPathHq') || str(ti, 'playPathAacv164') || str(ti, 'playUrl64') || str(ti, 'playUrl32');
      }
      var fallbackUrl = httpsUrl(fallbackChain);
      if (fallbackUrl && fallbackUrl.indexOf('http') === 0) return fallbackUrl;
    } catch (e) { if (e && e.cancelled) throw e; }

    if (list.length === 0) {
      throw new Error('本章节需要喜马拉雅会员或购买后才能收听：请在「书源管理 → 喜马拉雅」中登录已开通会员或已购该专辑的账号' +
        (str(json, 'msg') ? '（' + str(json, 'msg') + '）' : ''));
    }
    throw new Error('喜马拉雅播放地址解析失败，请稍后重试');
  }

  function readJsonCache(host, key, maxAgeSec) {
    try {
      if (typeof host.readCache !== 'function' || typeof host.cacheAge !== 'function') return null;
      var age = host.cacheAge(key);
      if (typeof age !== 'number' || age < 0 || age > maxAgeSec) return null;
      var txt = host.readCache(key);
      return txt ? JSON.parse(txt) : null;
    } catch (e) {
      return null;
    }
  }

  function writeJsonCache(host, key, obj) {
    try {
      if (typeof host.writeCache === 'function' && obj) {
        host.writeCache(key, JSON.stringify(obj));
      }
    } catch (e) {}
  }

  return {
    none: none,
    YUNTU_TOKEN: YUNTU_TOKEN,
    TINGYOU_SITE: TINGYOU_SITE,
    enc: function (s) { return encodeURIComponent(String(s || '').trim()); },
    nth: function (list, n) { return list && n < list.length ? list[n] : none; },

    findByText: function (node, selector, text) {
      if (!node || !node.exists()) return none;
      var list = node.select(selector);
      for (var i = 0; i < list.length; i++) {
        if (list[i].text().indexOf(text) >= 0) return list[i];
      }
      return none;
    },

    stripLabel: function (text) {
      return String(text || '').replace(/^\s*[一-龥A-Za-z]{1,4}\s*[：:]\s*/, '').trim();
    },

    unescape: function (s) {
      if (!s) return '';
      try { return JSON.parse('"' + String(s).replace(/"/g, '\\"') + '"'); }
      catch (e) { return String(s).replace(/\\\//g, '/'); }
    },

    httpsUrl: httpsUrl,
    cleanCover: httpsUrl,
    cleanHtml: cleanHtml,
    stripIntroPrefix: stripIntroPrefix,

    cleanChapterTitle: function (raw, bookTitle) {
      if (!raw) return '';
      var s = String(raw).trim()
        .replace(/\.(mp3|m4a|aac|wav|flac)$/i, '')
        .replace(/[_\s]*催更.*$/i, '')
        .replace(/【[^】]*(?:免费|订阅|关注|主播|上架|赞助|福利|公众号|微信|加群|催更)[^】]*】/g, '')
        .trim();
      if (bookTitle) {
        var escaped = String(bookTitle).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var stripped = s.replace(new RegExp('^《?' + escaped + '》?[\\s_\\-—:：|·]*', 'i'), '').trim();
        if (stripped.length > 0) s = stripped;
      }
      return s || String(raw).trim();
    },

    containsAudioExt: function (url) {
      var u = String(url || '').toLowerCase();
      return AUDIO_EXTS.some(function (e) { return u.indexOf(e) >= 0; });
    },

    getDoc: function (host, url, desktop, referer, encoding) {
      var o = { desktop: !!desktop };
      if (referer) o.headers = { Referer: referer };
      if (encoding) o.encoding = encoding;
      return host.getHtml(url, o);
    },

    coverReferer: function (domain, referer) {
      return function (coverUrl) { return String(coverUrl || '').indexOf(domain) >= 0 ? { Referer: referer } : null; };
    },

    hostOf: function (url) { return String(url || '').replace(/^https?:\/\//, '').split('/')[0]; },

    callTingyou: callTingyou,
    tingyouBaseUrl: tingyouBaseUrl,
    tingyouHeaders: tingyouHeaders,
    yuntuGetJson: yuntuGetJson,
    yuntuCurrentBase: yuntuCurrentBase,
    resolveXimalayaAudio: resolveXimalayaAudio,
    readJsonCache: readJsonCache,
    writeJsonCache: writeJsonCache
  };
})();
