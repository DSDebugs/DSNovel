// ---------- 喜马拉雅（DSNovel v5.6.8 排行榜三级联动 + 分类排序增强版） ----------
(function () {
  var WEB = 'https://www.ximalaya.com';
  var PAGE_SIZE = 200;
  var CHANNELS = ['youshengshu', 'guangbojv', 'xiangsheng', 'ertong', 'lishi', 'renwen', 'xiqu', 'qinggan'];
  var MENU_CACHE_KEY = 'xmly_cat_menus_v3';
  var MENU_CACHE_TTL = 86400; // 24 小时

  var FALLBACK_RANK_GROUPS = [
    {
      title: '全站',
      catId: '1',
      tabs: [
        { title: '热播', id: '100006' },
        { title: '完结', id: '100271' },
        { title: '新品', id: '100149' },
        { title: '飙升', id: '100004' },
        { title: '潜力', id: '100253' },
        { title: '口碑', id: '100145' },
        { title: 'VIP', id: '100028' }
      ]
    },
    {
      title: '小说',
      catId: '2',
      tabs: [
        { title: '热播', id: '100168' },
        { title: '完结', id: '100180' },
        { title: '新品', id: '100174' },
        { title: '飙升', id: '100167' },
        { title: '免费', id: '100001' }
      ]
    },
    { title: '相声评书', catId: '8', tabs: [{ title: '热播', id: '100088' }] },
    { title: '儿童', catId: '5', tabs: [{ title: '热播', id: '100092' }] },
    { title: '有声图书', catId: '44', tabs: [{ title: '热播', id: '100359' }] },
    { title: '人文国学', catId: '39', tabs: [{ title: '热播', id: '100105' }] },
    { title: '历史', catId: '10', tabs: [{ title: '热播', id: '100104' }] },
    { title: '悬疑', catId: '45', tabs: [{ title: '热播', id: '100364' }] },
    { title: '娱乐', catId: '4', tabs: [{ title: '热播', id: '100091' }] },
    { title: '音乐', catId: '7', tabs: [{ title: '热播', id: '100089' }] },
    { title: '个人成长', catId: '13', tabs: [{ title: '热播', id: '100107' }] },
    { title: '生活', catId: '14', tabs: [{ title: '热播', id: '100108' }] },
    { title: '健康', catId: '15', tabs: [{ title: '热播', id: '100109' }] },
    { title: '商业财经', catId: '9', tabs: [{ title: '热播', id: '100103' }] },
    { title: '外语', catId: '11', tabs: [{ title: '热播', id: '100106' }] },
    { title: '热点', catId: '6', tabs: [{ title: '热播', id: '100090' }] },
    { title: '广播剧', catId: '16', tabs: [{ title: '热播', id: '100110' }] },
    { title: '播客', catId: '47', tabs: [{ title: '热播', id: '100370' }] },
    { title: '影视', catId: '22', tabs: [{ title: '热播', id: '100115' }] }
  ];

  function web(host, url) {
    return host.getJson(url, { desktop: true, headers: { Referer: WEB + '/' } });
  }

  function cover(u) {
    var clean = Shun.cleanCover(u);
    if (!clean) return '';
    return clean.split('!')[0] + '!op_type=3&columns=640&rows=640';
  }

  function loggedIn(host) {
    return typeof host.cookies === 'function' && /(^|;\s*)1&_token=/.test(String(host.cookies(WEB + '/') || ''));
  }

  function albumUrl(id) { return WEB + '/album/' + id; }
  function albumId(url) { return (/album\/(\d+)/.exec(url) || [])[1] || ''; }
  function finished(v) { return String(v) === '2' ? '完结' : '连载'; }

  function isNonAlbumRank(title) {
    var t = String(title || '');
    return t.indexOf('主播') >= 0 || t.indexOf('声音') >= 0 || t.indexOf('电台') >= 0;
  }

  function formatPlayCount(n) {
    var num = Number(n) || 0;
    if (num >= 100000000) return (num / 100000000).toFixed(1) + '亿播放';
    if (num >= 10000) return (num / 10000).toFixed(0) + '万播放';
    return num > 0 ? (num + '播放') : '';
  }

  function extractInitialState(html) {
    var s = String(html || '');
    var marker = 'window.__INITIAL_STATE__';
    var idx = s.indexOf(marker);
    if (idx < 0) return null;
    var eq = s.indexOf('=', idx);
    var start = s.indexOf('{', eq);
    if (start < 0) return null;
    var end = s.indexOf('</script>', start);
    if (end < 0) end = s.length;
    var raw = s.substring(start, end).replace(/;\s*$/, '').trim();
    try { return parseJson(raw); } catch (e) { return null; }
  }

  function buildRankMenuFromDynamic(host) {
    var groups = [];
    try {
      var json = web(host, WEB + '/revision/rank/v4/getRankTabs?sceneId=1');
      var list = items(json, 'data.rankTabs');
      if (!list.length) list = items(json, 'data.tabLists');
      if (!list.length) list = items(json, 'data');
      list.forEach(function (g) {
        var gTitle = str(g, 'displayName') || str(g, 'name') || str(g, 'title');
        var catId = str(g, 'id') || str(g, 'categoryId') || str(g, 'clusterId') || '1';
        var subList = items(g, 'rankLists');
        if (!subList.length) subList = items(g, 'subTabs');
        if (!subList.length) subList = items(g, 'tabs');
        var tabs = [];
        subList.forEach(function (r) {
          var rTitle = str(r, 'displayName') || str(r, 'name') || str(r, 'title');
          var rId = str(r, 'rankingId') || str(r, 'rankId') || str(r, 'id');
          if (rTitle && rId && !isNonAlbumRank(rTitle)) {
            tabs.push({ title: rTitle, url: 'xm-rank:' + catId + ':' + rId + '#1' });
          }
        });
        if (gTitle && tabs.length > 0) groups.push({ title: gTitle, tabs: tabs });
      });
    } catch (e) {
      if (e && e.cancelled) throw e;
    }

    if (!groups.length) {
      FALLBACK_RANK_GROUPS.forEach(function (fg) {
        var tabs = fg.tabs.map(function (t) {
          return { title: t.title, url: 'xm-rank:' + fg.catId + ':' + t.id + '#1' };
        });
        groups.push({ title: fg.title, tabs: tabs });
      });
    }
    return { title: '排行榜', groups: groups };
  }

  function mapRankAlbum(a) {
    var id = str(a, 'albumId') || str(a, 'id');
    if (!id) return null;
    var title = Shun.cleanHtml(str(a, 'albumTitle') || str(a, 'title'));
    if (!title) return null;
    var cov = cover(str(a, 'cover') || str(a, 'coverPath') || str(a, 'albumCoverPath'));
    var artist = str(a, 'anchorName') || str(a, 'nickname') || str(a, 'albumUserNickName');
    var intro = Shun.stripIntroPrefix(str(a, 'description') || str(a, 'customTitle') || str(a, 'intro') || str(a, 'shortIntro'));
    var parts = [];
    if (a.isFinished !== undefined && a.isFinished !== null) parts.push(finished(a.isFinished));
    var tc = int(a, 'trackCount') || int(a, 'tracksCount');
    if (tc > 0) parts.push(tc + ' 章');
    var pc = formatPlayCount(a.playCount || a.play);
    if (pc) parts.push(pc);
    if (a.isPaid) parts.push('VIP/付费');
    return {
      bookUrl: albumUrl(id),
      title: title,
      coverUrl: cov,
      artist: artist,
      intro: intro,
      status: parts.join(' · ')
    };
  }

  function fetchRankAlbums(host, catId, rankId) {
    var albums = [];
    try {
      var json = web(host, WEB + '/revision/rank/v4/element?rankingId=' + encodeURIComponent(rankId));
      var rankLists = items(json, 'data.rankList');
      if (rankLists.length > 0 && Array.isArray(rankLists[0].albums)) {
        albums = rankLists[0].albums;
      } else {
        albums = items(json, 'data.albums');
        if (!albums.length) albums = rankLists;
      }
    } catch (e) {
      if (e && e.cancelled) throw e;
    }

    if (!albums.length && typeof host.getString === 'function') {
      try {
        var pageUrl = (catId === '1' && rankId === '100006')
          ? (WEB + '/top/')
          : (WEB + '/top/' + encodeURIComponent(catId) + '/' + encodeURIComponent(rankId));
        var html = host.getString(pageUrl, { desktop: true, headers: { Referer: WEB + '/' } });
        var state = extractInitialState(html);
        if (state) {
          var sLists = items(state, 'RankDetailPage.rankList');
          if (!sLists.length) sLists = items(state, 'rankDetail.rankList');
          if (!sLists.length) sLists = items(state, 'RootPage.rankList');
          if (sLists.length > 0 && Array.isArray(sLists[0].albums)) {
            albums = sLists[0].albums;
          } else if (sLists.length > 0) {
            albums = sLists;
          }
        }
      } catch (e2) {
        if (e2 && e2.cancelled) throw e2;
      }
    }

    var books = [], seen = {};
    albums.forEach(function (raw) {
      var mapped = mapRankAlbum(raw);
      if (mapped && !seen[mapped.bookUrl]) {
        seen[mapped.bookUrl] = true;
        books.push(mapped);
      }
    });
    return books;
  }

  registerSource({
    id: '6e2b9c4d8a1f4d37b5c0e73a9f1d2b64',
    name: '喜马拉雅',
    url: WEB + '/',
    group: '主力听书',
    description: '主力推荐 ⭐⭐⭐⭐⭐\n喜马拉雅排行榜与全频道有声书、多人有声剧、广播剧、相声评书、历史人文。免费内容免登录直听；VIP 与已购内容在书源管理页登录账号后即可收听全本。',
    multipleEpisodePages: true,
    loginUrl: 'https://m.ximalaya.com/login',
    loginDesktop: false,

    checkLogin: function () {
      var json = web(this.host, WEB + '/revision/main/getCurrentUser');
      if (int(json, 'ret') !== 200 || !at(json, 'data')) throw new Error('还没有登录喜马拉雅');
      return str(json, 'data.nickname') || str(json, 'data.nickName') || '喜马拉雅会员';
    },

    search: function (keywords, page) {
      var host = this.host, kw = String(keywords || '').trim();
      if (loggedIn(host)) {
        try {
          var album = at(web(host, WEB + '/revision/search/main?core=album&kw=' + encodeURIComponent(kw) + '&page=' + page +
            '&spellchecker=true&rows=20&condition=relation&device=iPhone&fq=&paidFilter=false'), 'data.album');
          var found = items(album, 'docs').filter(function (d) { return str(d, 'albumId'); }).map(function (d) {
            return {
              bookUrl: albumUrl(str(d, 'albumId')),
              title: Shun.cleanHtml(str(d, 'title')),
              coverUrl: cover(str(d, 'coverPath')),
              artist: str(d, 'nickname'),
              intro: Shun.stripIntroPrefix(str(d, 'customTitle') || str(d, 'intro')),
              status: finished(d.isFinished) + ' · ' + int(d, 'tracksCount') + ' 章' + (d.isPaid ? ' · VIP/付费' : '')
            };
          });
          if (found.length > 0) return { books: found, totalPage: Math.max(page, int(album, 'totalPage', page)) };
        } catch (e) {
          if (e && e.cancelled) throw e;
        }
      }

      function oldSearch(word, p) {
        var r = at(host.getJson('https://search.ximalaya.com/front/v1?core=album&kw=' + encodeURIComponent(word) + '&page=' + p +
          '&rows=20&spellchecker=true&condition=relation&device=android&version=9.0.75&paidFilter=false'), 'response');
        return {
          totalPage: int(r, 'totalPage', p),
          books: items(r, 'docs').map(function (d) {
            return {
              bookUrl: albumUrl(str(d, 'id')),
              title: Shun.cleanHtml(str(d, 'title')),
              coverUrl: cover(str(d, 'cover_path')),
              artist: str(d, 'nickname'),
              intro: Shun.stripIntroPrefix(str(d, 'custom_title') || str(d, 'intro')),
              status: finished(d.is_finished) + ' · ' + int(d, 'tracks') + ' 章' + (d.is_paid ? ' · VIP/付费' : '')
            };
          })
        };
      }

      var result = oldSearch(kw, page), books = result.books;
      if (page === 1 && books.length < 3 && kw.length >= 4 && kw.indexOf(' ') < 0) {
        var seen = {};
        books.forEach(function (b) { seen[b.bookUrl] = true; });
        try {
          oldSearch(kw.substring(0, kw.length - 1), 1).books.forEach(function (b) {
            if (!seen[b.bookUrl]) { seen[b.bookUrl] = true; books.push(b); }
          });
        } catch (e) { if (e && e.cancelled) throw e; }
      }
      return { books: books, totalPage: Math.max(page, result.totalPage) };
    },

    categoryMenus: function () {
      var cached = Shun.readJsonCache(this.host, MENU_CACHE_KEY, MENU_CACHE_TTL);
      if (Array.isArray(cached) && cached.length > 0) return cached;

      var menus = [buildRankMenuFromDynamic(this.host)];
      try {
        var groups = items(web(this.host, WEB + '/revision/category/allCategoryInfo'), 'data');
        var found = {};
        groups.forEach(function (g) {
          items(g, 'categories').forEach(function (c) { found[str(c, 'pinyin')] = c; });
        });
        CHANNELS.forEach(function (pinyin) {
          var c = found[pinyin];
          if (!c) return;
          var tabs = [{ title: '全部', url: 'xm-cat:' + pinyin + ':#1' }];
          items(c, 'subcategories').forEach(function (s) {
            if (str(s, 'code')) tabs.push({ title: str(s, 'displayValue'), url: 'xm-cat:' + pinyin + ':' + str(s, 'code') + '#1' });
          });
          menus.push({ title: str(c, 'displayName'), tabs: tabs });
        });
      } catch (e) {
        if (e && e.cancelled) throw e;
      }
      if (menus.length > 0) Shun.writeJsonCache(this.host, MENU_CACHE_KEY, menus);
      return menus;
    },

    categoryPage: function (url) {
      var rm = /^xm-rank:([^:]+):([^#]+)#(\d+)$/.exec(url);
      if (rm) {
        var rankBooks = fetchRankAlbums(this.host, rm[1], rm[2]);
        return {
          books: rankBooks,
          currentPage: 1,
          totalPage: 1,
          nextUrl: null
        };
      }

      var m = /^xm-cat:([^:]*):([^:#]*)(?::(\d+))?#(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var sortCode = m[3] ? parseInt(m[3], 10) : 1;
      var page = parseInt(m[4], 10), perPage = 30;
      var data = at(web(this.host, WEB + '/revision/category/queryCategoryPageAlbums?category=' + m[1] + '&subcategory=' + m[2] +
        '&meta=&sort=' + sortCode + '&page=' + page + '&perPage=' + perPage), 'data');
      var books = items(data, 'albums').map(function (a) {
        return {
          bookUrl: albumUrl(str(a, 'albumId')),
          title: Shun.cleanHtml(str(a, 'title')),
          coverUrl: cover(str(a, 'coverPath')),
          artist: str(a, 'anchorName'),
          intro: Shun.stripIntroPrefix(str(a, 'intro') || str(a, 'customTitle')),
          status: finished(a.isFinished) + ' · ' + int(a, 'trackCount') + ' 章' + (a.isPaid ? ' · VIP/付费' : '')
        };
      });
      var total = Math.min(50, Math.ceil(int(data, 'total') / perPage));
      var sortSuffix = m[3] ? (':' + sortCode) : '';
      return {
        books: books,
        currentPage: page,
        totalPage: Math.max(total, page),
        nextUrl: books.length > 0 && page < total ? 'xm-cat:' + m[1] + ':' + m[2] + sortSuffix + '#' + (page + 1) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, id = albumId(bookUrl);
      var detail = { episodes: [] };
      try {
        var info = at(web(host, WEB + '/revision/album/v1/simple?albumId=' + id), 'data.albumPageMainInfo') || {};
        detail.title = Shun.cleanHtml(str(info, 'albumTitle'));
        detail.coverUrl = cover(str(info, 'cover'));
        detail.artist = str(info, 'anchorName');
        detail.intro = Shun.stripIntroPrefix(str(info, 'richIntro') || str(info, 'shortIntro'));
        detail.status = finished(info.isFinished);
      } catch (e) {
        if (e && e.cancelled) throw e;
      }
      if (!loadEpisodes) return detail;

      var useBackup = false;
      function makePageUrl(p) {
        return useBackup
          ? ('https://mobile.ximalaya.com/mobile/others/ca/album/track/' + id + '/true/' + p + '/' + PAGE_SIZE)
          : ('https://mobile.ximalaya.com/mobile/v1/album/track?albumId=' + id + '&pageId=' + p + '&pageSize=' + PAGE_SIZE + '&isAsc=true&device=android');
      }

      function extractPageData(json) {
        if (!useBackup) {
          return int(json, 'ret') === 0 ? at(json, 'data') : null;
        }
        return (int(json, 'ret') === 0 && at(json, 'tracks')) ? at(json, 'tracks') : null;
      }

      function appendTracks(data) {
        items(data, 'list').forEach(function (t, idx) {
          var tid = str(t, 'trackId');
          if (!tid) return;
          var cleaned = Shun.cleanChapterTitle(Shun.cleanHtml(str(t, 'title')), detail.title);
          detail.episodes.push({
            title: cleaned || ('第 ' + (detail.episodes.length + 1) + ' 章'),
            url: 'xm:' + tid,
            isFree: !t.isPaid || !!t.isFree || !!t.isAuthorized
          });
        });
      }

      var firstJson = host.getJson(makePageUrl(1));
      var firstData = extractPageData(firstJson);
      if (!firstData) {
        var reason = str(firstJson, 'msg');
        useBackup = true;
        var backupJson = host.getJson(makePageUrl(1));
        firstData = extractPageData(backupJson);
        if (!firstData) {
          throw new Error('喜马拉雅：' + (reason || str(backupJson, 'msg') || '获取章节列表失败'));
        }
      }

      appendTracks(firstData);
      var maxPage = Math.min(500, int(firstData, 'maxPageId', 1));
      if (!loadFullPages || maxPage <= 1) return detail;

      try {
        var urls = [];
        for (var p = 2; p <= maxPage; p++) urls.push(makePageUrl(p));
        var conc = maxPage > 4 ? 4 : 6;
        for (var i = 0; i < urls.length; i += conc) {
          var batch = urls.slice(i, i + conc);
          host.progress(Math.min(i + batch.length + 1, maxPage) + ' / ' + maxPage);
          var texts = host.getStrings(batch, {}, conc) || [];
          for (var j = 0; j < batch.length; j++) {
            var txt = texts[j];
            var pageData = null;
            if (txt) {
              try { pageData = extractPageData(parseJson(txt)); } catch (e) {}
            }
            if (!pageData) {
              try { pageData = extractPageData(host.getJson(batch[j])); } catch (e2) { if (e2 && e2.cancelled) throw e2; }
            }
            if (pageData) appendTracks(pageData);
          }
        }
      } finally {
        host.progress(null);
      }
      return detail;
    },

    audio: function (url, quality) {
      return Shun.resolveXimalayaAudio(this.host, url, quality);
    }
  });
})();
