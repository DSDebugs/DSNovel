// ---------- 精品正版/高速 JSON 接口有声小说源合集 (api_audiobook.js v5.6.4) ----------

// ---------- 1. 听友听书（tingyou.fm） ----------
(function () {
  var SITE = Shun.TINGYOU_SITE;
  var FILTER_CACHE_KEY = 'tingyou_filters_v2';
  var FILTER_CACHE_TTL = 86400; // 24 小时
  var SORTS = { '综合排序': 'comprehensive', '播放最多': 'popular', '最近更新': 'updated', '最新发布': 'new' };

  function albumId(url) {
    var m = /album\/(\d+)/.exec(url);
    if (!m) throw new Error('不认识的专辑地址：' + url);
    return m[1];
  }

  function toBook(a) {
    var count = int(a, 'count');
    var author = str(a, 'author').trim();
    var teller = str(a, 'teller').trim();
    return {
      coverUrl: Shun.cleanCover(str(a, 'cover_url')),
      bookUrl: SITE + '/listening/album/' + str(a, 'id'),
      title: Shun.cleanHtml(str(a, 'title')),
      author: author,
      artist: teller || author,
      intro: Shun.stripIntroPrefix(str(a, 'intro') || str(a, 'description') || str(a, 'synopsis')),
      status: (int(a, 'status') === 0 ? '已完结' : '连载中') + (count > 0 ? ' · ' + count + ' 章' : '')
    };
  }

  registerSource({
    id: 'a6d1c3f08b2e4759b8e0f4a27c915d36',
    name: '听友听书',
    url: SITE + '/listening',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n有声小说和名家评书非常全，更新快。采用官方 JSON 接口，免登录直连，全本目录单次秒加载。',
    config: [{ type: 'select', key: 'sort', label: '分类排序方式', default: '播放最多', options: ['综合排序', '播放最多', '最近更新', '最新发布'] }],

    search: function (keywords, page) {
      var json = Shun.callTingyou(this.host, 'search', { keyword: keywords, page: page });
      var books = items(json, 'results').map(toBook);
      return { books: books, totalPage: at(json, 'has_more') && books.length > 0 ? page + 1 : page };
    },

    categoryMenus: function () {
      var menus = [{
        title: '热播榜单',
        tabs: [['热门播放', 'hot'], ['最新上架', 'latest'], ['精品推荐', 'recommend'], ['热门连载', 'serial']].map(function (t) {
          return { title: t[0], url: 'tingyou:rank:' + t[1] + '#1' };
        })
      }];
      var filters = Shun.readJsonCache(this.host, FILTER_CACHE_KEY, FILTER_CACHE_TTL);
      if (!filters) {
        filters = Shun.callTingyou(this.host, 'filters');
        if (filters && items(filters, 'categories').length > 0) {
          Shun.writeJsonCache(this.host, FILTER_CACHE_KEY, filters);
        }
      }
      items(filters, 'categories').forEach(function (c) {
        var tabs = [{ title: '全部', url: 'tingyou:cat:category=' + str(c, 'id') + '#1' }].concat(items(c, 'types').map(function (t) {
          return { title: str(t, 'name'), url: 'tingyou:cat:type=' + str(t, 'id') + '#1' };
        }));
        menus.push({ title: str(c, 'name'), tabs: tabs });
      });
      return menus;
    },

    categoryPage: function (url) {
      var m = /^tingyou:(rank|cat):([^#]+)#(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var page = parseInt(m[3], 10), next = 'tingyou:' + m[1] + ':' + m[2] + '#' + (page + 1), books, total;
      if (m[1] === 'rank') {
        var r = Shun.callTingyou(this.host, 'rank?section=' + m[2] + '&page=' + page, undefined, true);
        books = items(r, 'items').map(toBook);
        var size = int(r, 'page_size', 30) || 30;
        total = at(r, 'has_more') ? Math.max(page + 1, Math.ceil(int(r, 'total') / size)) : page;
      } else {
        var sort = SORTS[this.host.getPref('sort', '播放最多')] || 'popular';
        var c = Shun.callTingyou(this.host, 'category?sort=' + sort + '&' + m[2] + '&page=' + page, undefined, true);
        books = items(c, 'data').map(toBook);
        total = Math.max(page, int(c, 'pages', page));
      }
      if (books.length === 0) total = page;
      return { books: books, currentPage: page, totalPage: total, nextUrl: page < total ? next : null };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var host = this.host;
      var id = albumId(bookUrl);
      var a = null, c = null;
      if (loadEpisodes) {
        var base = Shun.tingyouBaseUrl(host);
        var hdrs = Shun.tingyouHeaders(host);
        var pair = [];
        try {
          pair = host.getStrings([base + '/h5/listening/album/' + id, base + '/h5/listening/chapters/' + id], { headers: hdrs }, 2) || [];
        } catch (e) { if (e && e.cancelled) throw e; }
        try { if (pair[0]) a = parseJson(pair[0]); } catch (e) {}
        try { if (pair[1]) c = parseJson(pair[1]); } catch (e) {}
      }
      if (!a || at(a, 'error')) a = Shun.callTingyou(host, 'album/' + id);
      if (at(a, 'available') === false) throw new Error('这本书已经下架了');
      var detail = toBook(a);
      detail.episodes = [];
      if (loadEpisodes) {
        if (!c || at(c, 'error')) c = Shun.callTingyou(host, 'chapters/' + id);
        detail.episodes = items(c, 'chapters').map(function (ch) {
          return {
            title: Shun.cleanChapterTitle(str(ch, 'title'), detail.title) || ('第 ' + int(ch, 'index') + ' 章'),
            url: SITE + '/listening/album/' + id + '#' + int(ch, 'index'),
            isFree: true
          };
        });
      }
      return detail;
    },

    audio: function (url) {
      var m = /album\/(\d+)#(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的章节地址：' + url);
      var json = Shun.callTingyou(this.host, 'play', { album_id: m[1], chapter_idx: parseInt(m[2], 10) });
      var play = str(json, 'play_url');
      if (!play) throw new Error(str(json, 'detail') || str(json, 'message') || '没有拿到播放地址');
      return Shun.httpsUrl(play);
    }
  });
})();

// ---------- 2. 云图有声（yuntuys.com）：HTTPS 优先回退 + 详情元数据补齐 ----------
(function () {
  var WECHAT = Shun.YUNTU_TOKEN;

  function parseBook(i) {
    var author = str(i, 'authorName').trim();
    var anchor = str(i, 'anchorName').trim();
    return {
      coverUrl: Shun.cleanCover(str(i, 'cover')),
      bookUrl: str(i, 'bookId'),
      title: Shun.cleanHtml(str(i, 'bookName')),
      author: author,
      artist: anchor || author,
      status: int(i, 'chapters') > 0 ? ('共 ' + int(i, 'chapters') + ' 章') : '正版有声',
      intro: Shun.stripIntroPrefix(str(i, 'summary'))
    };
  }
  function chaptersSubPath(bookId, p) {
    return 'getChapters/' + WECHAT + '/' + bookId + '/true/asc?pageSize=200&pageNum=' + p;
  }
  function parseChapters(q, bookTitle) {
    return items(q, 'list').map(function (i, idx) {
      return {
        title: Shun.cleanChapterTitle(str(i, 'name'), bookTitle || '') || ('第 ' + (idx + 1) + ' 章'),
        url: Shun.httpsUrl(str(i, 'audioUrl')),
        isFree: true
      };
    });
  }

  registerSource({
    id: 'ab0a5474cd6a40e3ba65045addad390a',
    name: '云图有声',
    url: 'https://yuntuwechat.yuntuys.com/home',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n正版有声书平台，涵盖畅销小说、悬疑推理、广播剧、经典文学、历史少儿等，全集免登录直链秒播。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var data = at(Shun.yuntuGetJson(this.host, 'search/' + WECHAT + '/' + Shun.enc(keywords) + '?pageSize=20&pageNum=' + page), 'data');
      return { books: items(data, 'list').map(parseBook), totalPage: Math.max(1, int(data, 'totalPage')) };
    },

    categoryMenus: function () {
      function menu(title, list) {
        return {
          title: title,
          tabs: list.map(function (p) { return { title: p[0], url: 'yuntu:type:' + p[1] + '#1' }; })
        };
      }
      return [
        menu('畅销小说', [['悬疑推理', 142], ['现代都市', 143], ['怪奇物语', 144], ['侠义江湖', 335], ['科学幻想', 139], ['国风古韵', 137], ['官场商战', 140], ['军事谍战', 141], ['青春校园', 138]]),
        menu('特色精选', [['豆瓣高分', 125], ['广播剧', 126], ['影视同期', 127], ['听见真知', 124], ['远读重洋', 571]]),
        menu('经典文学', [['世界名著', 131], ['中国文学', 132], ['国学经典', 134], ['外国文学', 133], ['诗词散文', 135], ['人物传记', 136]]),
        menu('文化历史', [['古代历史', 165], ['近现代史', 166], ['世界历史', 167], ['传奇史话', 168], ['民俗文化', 161], ['哲学思想', 164]]),
        menu('少儿教育', [['儿童文学', 152], ['童话名著', 153], ['国学启蒙', 154], ['百科知识', 156]])
      ];
    },

    categoryPage: function (url) {
      var m = /^yuntu:type:(\d+)#(\d+)$/.exec(url);
      var subPath, currentReqPage = 1;
      if (m) {
        currentReqPage = parseInt(m[2], 10) || 1;
        subPath = 'getBookListByType/' + WECHAT + '/' + m[1] + '?pageNum=' + currentReqPage + '&pageSize=20';
      } else {
        subPath = String(url).replace(/^https?:\/\/[^/]+\/api\/w_ys\/book\//i, '');
      }
      var data = at(Shun.yuntuGetJson(this.host, subPath), 'data');
      var current = int(data, 'pageNumber', currentReqPage);
      var total = Math.max(current, int(data, 'totalPage', 1));
      var nextUrl = null;
      if (current < total) {
        nextUrl = m ? ('yuntu:type:' + m[1] + '#' + (current + 1)) : url.replace(/pageNum=\d+/, 'pageNum=' + (current + 1));
      }
      return {
        books: items(data, 'list').map(parseBook),
        currentPage: current,
        totalPage: total,
        nextUrl: nextUrl
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var detail = { episodes: [] };
      var firstJson = Shun.yuntuGetJson(host, chaptersSubPath(bookUrl, 1));
      var bookObj = at(firstJson, 'data.book') || at(firstJson, 'data.bookInfo') || {};
      if (str(bookObj, 'bookName')) detail.title = Shun.cleanHtml(str(bookObj, 'bookName'));
      if (str(bookObj, 'cover')) detail.coverUrl = Shun.cleanCover(str(bookObj, 'cover'));
      if (str(bookObj, 'anchorName') || str(bookObj, 'authorName')) {
        detail.artist = str(bookObj, 'anchorName').trim() || str(bookObj, 'authorName').trim();
      }
      if (str(bookObj, 'summary')) detail.intro = Shun.stripIntroPrefix(str(bookObj, 'summary'));
      if (!loadEpisodes) return detail;

      var query = at(firstJson, 'data.pageQuery');
      var total = Math.min(50, int(query, 'totalPage', 1));
      var list = parseChapters(query, detail.title || '');
      if (loadFullPages && total > 1) {
        try {
          var base = Shun.yuntuCurrentBase(host);
          var urls = [];
          for (var p = 2; p <= total; p++) urls.push(base + chaptersSubPath(bookUrl, p));
          for (var i = 0; i < urls.length; i += 6) {
            var batch = urls.slice(i, i + 6);
            host.progress(Math.min(i + batch.length + 1, total) + ' / ' + total);
            var texts = host.getStrings(batch, {}, 6) || [];
            for (var j = 0; j < batch.length; j++) {
              var chs = [];
              if (texts[j]) {
                try { chs = parseChapters(at(parseJson(texts[j]), 'data.pageQuery'), detail.title || ''); } catch (e) {}
              }
              if (chs.length === 0) {
                try { chs = parseChapters(at(host.getJson(batch[j]), 'data.pageQuery'), detail.title || ''); } catch (e2) { if (e2 && e2.cancelled) throw e2; }
              }
              if (chs.length > 0) list = list.concat(chs);
            }
          }
        } finally {
          host.progress(null);
        }
      }
      detail.episodes = list;
      return detail;
    }
  });
})();

// ---------- 3. 博看有声（bookan.com.cn）：修复精选专辑加载、2路并发搜索、补全演播与简介 ----------
(function () {
  var INSTANCE = '25304';
  var lastPages = {};
  var lastPageKeys = [];
  var albumListBroken = false;
  var ALBUM_BROKEN_CACHE_KEY = 'bookan_album_list_broken';
  var ALBUM_BROKEN_TTL_SEC = 6 * 3600;

  function isAlbumListBroken(host) {
    return albumListBroken;
  }

  function markAlbumListBroken(host) {
    albumListBroken = true;
  }

  function unitsUrl(bookUrl, p) {
    return 'https://api.bookan.com.cn/voice/album/units?album_id=' + bookUrl + '&page=' + p + '&num=200&order=1';
  }
  function parseUnits(data, bookTitle) {
    return items(data, 'list').map(function (i, idx) {
      return {
        title: Shun.cleanChapterTitle(str(i, 'title'), bookTitle || '') || ('第 ' + (idx + 1) + ' 章'),
        url: Shun.httpsUrl(str(i, 'file')),
        isFree: true
      };
    });
  }

  function mapBookanItem(i) {
    var author = Shun.cleanHtml(str(i, 'author') || str(i, 'author_name') || str(i, 'writer'));
    var artist = Shun.cleanHtml(str(i, 'anchor') || str(i, 'anchor_name') || str(i, 'announcer') || str(i, 'speaker') || author);
    var intro = Shun.stripIntroPrefix(str(i, 'description') || str(i, 'intro') || str(i, 'brief') || str(i, 'summary') || str(i, 'content'));
    var total = int(i, 'total') || int(i, 'units_count') || int(i, 'unit_count');
    return {
      coverUrl: Shun.cleanCover(str(i, 'cover') || str(i, 'thumb') || str(i, 'img')),
      bookUrl: str(i, 'id') || str(i, 'album_id'),
      title: Shun.cleanHtml(str(i, 'name') || str(i, 'title')),
      author: author,
      artist: artist,
      intro: intro,
      status: total > 0 ? ('共 ' + total + ' 章') : '正版有声'
    };
  }

  function rememberKeyword(kw) {
    if (lastPages[kw]) return lastPages[kw];
    lastPages[kw] = {};
    lastPageKeys.push(kw);
    if (lastPageKeys.length > 50) {
      var oldest = lastPageKeys.shift();
      delete lastPages[oldest];
    }
    return lastPages[kw];
  }

  registerSource({
    id: 'c98a21452583434da5cfef8be16b71d6',
    name: '博看有声',
    url: 'https://voicewk.bookan.com.cn/25303/index',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n图书馆正版数字有声资源，涵盖历史小说、国学经典、相声评书、文学名著、人文社科，免登录直链播放。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var host = this.host, books = [], seen = {};
      var known = rememberKeyword(keywords);
      var types = [];
      var urls = [];
      ['book', 'album'].forEach(function (type) {
        if (known[type] !== undefined && page > known[type]) return;
        types.push(type);
        urls.push('https://es.bookan.com.cn/api/v3/voice/' + type + '?instanceId=' + INSTANCE +
          '&keyword=' + Shun.enc(keywords) + '&pageNum=' + page + '&limitNum=20');
      });
      if (urls.length === 0) return { books: [], totalPage: page };

      var texts = host.getStrings(urls, {}, urls.length) || [];
      var successCount = 0;
      for (var t = 0; t < types.length; t++) {
        var txt = texts[t];
        if (!txt) continue;
        try {
          var json = parseJson(txt);
          successCount++;
          known[types[t]] = int(json, 'data.last_page', 0);
          items(json, 'data.list').forEach(function (i) {
            var mapped = mapBookanItem(i);
            if (!mapped.bookUrl || !mapped.title || seen[mapped.bookUrl]) return;
            seen[mapped.bookUrl] = true;
            books.push(mapped);
          });
        } catch (e) {}
      }
      if (successCount === 0) throw new Error('博看有声搜索失败，请稍后再试');
      return { books: books, totalPage: Math.max(page, known.book || 0, known.album || 0) };
    },

    categoryMenus: function () {
      function bookTabs(list) {
        return list.map(function (p) {
          return { title: p[0], url: 'bookan:book:' + p[1] + ':' + encodeURIComponent(p[0]) + '#1' };
        });
      }
      function albumTabs(list) {
        return list.map(function (p) {
          return { title: p[0], url: 'bookan:album:' + p[1] + ':' + encodeURIComponent(p[0]) + '#1' };
        });
      }
      return [
        {
          title: '有声图书',
          tabs: bookTabs([
            ['历史小说', 1312], ['经典必读', 1314], ['相声评书', 1319], ['故事会', 1303], ['国学经典', 1320],
            ['文学文艺', 1306], ['商业财经', 1315], ['心理哲学', 1310], ['青春励志', 1307], ['少年读物', 1305],
            ['儿童文学', 1304], ['科技科普', 1313], ['社会观察', 1318], ['音乐戏曲', 1317]
          ])
        },
        {
          title: '精选专辑',
          tabs: albumTabs([
            ['文史军事', 10], ['人文社科', 8], ['休闲娱乐', 5], ['财经科技', 6], ['少儿学堂', 9],
            ['健康养生', 4], ['投资理财', 11], ['自我提升', 17]
          ])
        }
      ];
    },

    categoryPage: function (url) {
      var host = this.host;
      var m = /^bookan:(book|album):(\d+):([^#]*)#(\d+)$/.exec(url);
      if (m) {
        var type = m[1], catId = m[2], label = m[3] || '', page = parseInt(m[4], 10) || 1;
        try { label = decodeURIComponent(label); } catch (e) {}
        var books = [], current = page, total = page;

        // 1. 优先请求官方分类列表（若精选专辑接口已知不可用则直接走 ES 稳定通道）
        if (type === 'book' || !isAlbumListBroken(host)) {
          try {
            var listUrl = 'https://api.bookan.com.cn/voice/' + type + '/list?instance_id=' + INSTANCE +
              '&page=' + page + '&category_id=' + catId + '&num=24';
            var data = at(host.getJson(listUrl), 'data');
            var raw = items(data, 'list');
            if (raw.length > 0) {
              books = raw.map(mapBookanItem);
              current = int(data, 'current_page', page);
              total = Math.max(current, int(data, 'last_page', page));
            } else if (type === 'album') {
              markAlbumListBroken(host);
            }
          } catch (e) {
            if (e && e.cancelled) throw e;
            if (type === 'album') markAlbumListBroken(host);
            else throw e;
          }
        }

        // 2. 精选专辑容灾回退：使用高命中率 2 字核心主题词 + 备用词查 ES 专辑通道（避免 4 字分类名 0 命中）
        if (books.length === 0 && type === 'album' && label) {
          var ALBUM_ES_KEYWORDS = {
            '文史军事': ['历史', '军事'],
            '人文社科': ['文化', '人文'],
            '休闲娱乐': ['故事', '相声'],
            '财经科技': ['财经', '商业'],
            '少儿学堂': ['儿童', '童话'],
            '健康养生': ['养生', '健康'],
            '投资理财': ['理财', '经济'],
            '自我提升': ['心理', '成长']
          };
          var kwList = ALBUM_ES_KEYWORDS[label] || [label.slice(0, 2), label];
          for (var ki = 0; ki < kwList.length && books.length === 0; ki++) {
            var kw = kwList[ki];
            if (!kw) continue;
            var esUrl = 'https://es.bookan.com.cn/api/v3/voice/album?instanceId=' + INSTANCE +
              '&keyword=' + Shun.enc(kw) + '&pageNum=' + page + '&limitNum=24';
            try {
              var esData = at(host.getJson(esUrl), 'data');
              var esRaw = items(esData, 'list');
              if (esRaw.length > 0) {
                books = esRaw.map(mapBookanItem);
                current = page;
                total = Math.max(current, int(esData, 'last_page', page));
              }
            } catch (esErr) {
              if (esErr && esErr.cancelled) throw esErr;
            }
          }
        }

        return {
          books: books,
          currentPage: current,
          totalPage: total,
          nextUrl: current < total ? ('bookan:' + type + ':' + catId + ':' + encodeURIComponent(label) + '#' + (current + 1)) : null
        };
      }

      // 兼容旧版直链 URL
      var legacyData = at(host.getJson(url), 'data');
      var lCur = int(legacyData, 'current_page', 1), lTot = int(legacyData, 'last_page', 1);
      return {
        books: items(legacyData, 'list').map(mapBookanItem),
        currentPage: lCur,
        totalPage: lTot,
        nextUrl: lCur < lTot ? url.replace(/page=\d+/, 'page=' + (lCur + 1)) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var detail = { episodes: [] };

      // 并发拉取专辑元数据与第 1 页章节，补齐详情页完整简介与主播
      var reqUrls = ['https://api.bookan.com.cn/voice/album/info?album_id=' + bookUrl + '&instance_id=' + INSTANCE];
      if (loadEpisodes) reqUrls.push(unitsUrl(bookUrl, 1));

      var texts = [];
      try {
        texts = host.getStrings(reqUrls, {}, reqUrls.length) || [];
      } catch (e) { if (e && e.cancelled) throw e; }

      if (texts[0]) {
        try {
          var infoObj = at(parseJson(texts[0]), 'data') || {};
          var mapped = mapBookanItem(infoObj);
          if (mapped.title) detail.title = mapped.title;
          if (mapped.coverUrl) detail.coverUrl = mapped.coverUrl;
          if (mapped.author) detail.author = mapped.author;
          if (mapped.artist) detail.artist = mapped.artist;
          if (mapped.intro) detail.intro = mapped.intro;
          if (mapped.status) detail.status = mapped.status;
        } catch (e) {}
      }

      if (!loadEpisodes) return detail;

      var data = null;
      if (texts[1]) {
        try { data = at(parseJson(texts[1]), 'data'); } catch (e) {}
      }
      if (!data) data = at(host.getJson(unitsUrl(bookUrl, 1)), 'data');

      var total = Math.min(50, int(data, 'last_page', 1));
      var list = parseUnits(data, detail.title || '');
      if (loadFullPages && total > 1) {
        try {
          var urls = [];
          for (var p = 2; p <= total; p++) urls.push(unitsUrl(bookUrl, p));
          for (var i = 0; i < urls.length; i += 6) {
            var batch = urls.slice(i, i + 6);
            host.progress(Math.min(i + batch.length + 1, total) + ' / ' + total);
            var texts = host.getStrings(batch, {}, 6) || [];
            for (var j = 0; j < batch.length; j++) {
              var units = [];
              if (texts[j]) {
                try { units = parseUnits(at(parseJson(texts[j]), 'data'), detail.title || ''); } catch (e) {}
              }
              if (units.length === 0) {
                try { units = parseUnits(at(host.getJson(batch[j]), 'data'), detail.title || ''); } catch (e2) { if (e2 && e2.cancelled) throw e2; }
              }
              if (units.length > 0) list = list.concat(units);
            }
          }
        } finally {
          host.progress(null);
        }
      }
      detail.episodes = list;
      return detail;
    }
  });
})();
