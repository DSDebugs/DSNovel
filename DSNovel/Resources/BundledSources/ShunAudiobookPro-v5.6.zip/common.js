// DSNovel 听书专享优化版公共辅助库 (common.js)
var Shun = (function () {
  var AUDIO_EXTS = ['.m4a', '.mp3', '.m4b', '.flac', '.aa3', '.ogg', '.wma', '.wav', '.aac', '.ac3', '.mp4'];

  var none = {
    exists: function () { return false; },
    text: function () { return ''; },
    ownText: function () { return ''; },
    attr: function () { return ''; },
    absUrl: function () { return ''; },
    first: function () { return none; },
    select: function () { return []; }
  };

  return {
    none: none,
    enc: function (s) { return encodeURIComponent(String(s || '').trim()); },

    nth: function (list, n) { return list && n < list.length ? list[n] : none; },

    findByText: function (node, selector, text) {
      if (!node || !node.exists()) return none;
      var list = node.select(selector);
      for (var i = 0; i < list.length; i++) {
        if (list[i].text().indexOf(text) >= 0) return list[i];
      }
      return none;
    },

    stripLabel: function (text) {
      return String(text || '').replace(/^\s*[一-龥A-Za-z]{1,4}\s*[：:]\s*/, '').trim();
    },

    unescape: function (s) {
      if (!s) return '';
      try { return JSON.parse('"' + String(s).replace(/"/g, '\\"') + '"'); }
      catch (e) { return String(s).replace(/\\\//g, '/'); }
    },

    httpsUrl: function (u) {
      if (!u) return '';
      var s = String(u).trim();
      if (s.indexOf('//') === 0) return 'https:' + s;
      return s.replace(/^http:\/\//i, 'https://');
    },

    /** 清洗简介与标题中的 HTML 标签、内联样式及常见 HTML 实体（解决喜马拉雅等源简介出现 <p data-flag="normal"...> 的问题） */
    cleanHtml: function (raw) {
      if (!raw) return '';
      return String(raw)
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p\s*>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/[ \t\r]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
    },

    /** 清洗章节标题：剥离扩展名、催更群号广告尾巴及重复的书名前缀 */
    cleanChapterTitle: function (raw, bookTitle) {
      if (!raw) return '';
      var s = String(raw).trim()
        .replace(/\.(mp3|m4a|aac|wav|flac)$/i, '')
        .replace(/[_\s]*催更.*$/i, '')
        .replace(/【[^】]*(?:免费|订阅|关注|主播|上架|赞助|福利|公众号|微信|加群|催更)[^】]*】/g, '')
        .trim();
      if (bookTitle) {
        var escaped = String(bookTitle).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var stripped = s.replace(new RegExp('^《?' + escaped + '》?[\\s_\\-—:：|·]*', 'i'), '').trim();
        if (stripped.length > 0) s = stripped;
      }
      return s || String(raw).trim();
    },

    containsAudioExt: function (url) {
      var u = String(url || '').toLowerCase();
      return AUDIO_EXTS.some(function (e) { return u.indexOf(e) >= 0; });
    },

    getDoc: function (host, url, desktop, referer, encoding) {
      var o = { desktop: !!desktop };
      if (referer) o.headers = { Referer: referer };
      if (encoding) o.encoding = encoding;
      return host.getHtml(url, o);
    },

    coverReferer: function (domain, referer) {
      return function (coverUrl) { return String(coverUrl || '').indexOf(domain) >= 0 ? { Referer: referer } : null; };
    },

    hostOf: function (url) { return String(url || '').replace(/^https?:\/\//, '').split('/')[0]; }
  };
})();
