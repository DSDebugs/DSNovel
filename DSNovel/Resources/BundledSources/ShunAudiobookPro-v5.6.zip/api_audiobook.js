// ---------- 精品正版/高速 JSON 接口有声小说源合集 (api_audiobook.js) ----------
// 已剔除原 api.js 中的哔哩哔哩(视频)、蜻蜓FM、书音FM、心理FM、央视听音、百家讲坛、新闻联播、网易云音乐、网易云播客及高付费锁酷我畅听。
// 仅保留 4 个高质量纯听书 JSON 接口源：听友听书、云图有声、博看有声、懒人听书，并将章节翻页全部升级为 6 路并发极速加载。

// ---------- 1. 听友听书（tingyou.fm）：全本有声小说与评书 JSON 接口，单次返回全集目录 ----------
(function () {
  var SITE = 'https://tingyou.fm';
  var BASES = [
    'https://api-preview.toulaopao.cc/api',
    'https://appp.fdhtbz.cn/api',
    'https://laopaoaappi.oobyvy.vip/api'
  ];
  var working = null;
  var session = null;
  var filters = null;

  function options(host, body) {
    if (!session) session = host.uuid();
    var o = {
      headers: {
        Origin: SITE,
        Referer: SITE + '/',
        Accept: 'application/json',
        'x-listening-session': session,
        'x-listening-timezone': 'Asia/Shanghai'
      }
    };
    if (body !== undefined) {
      o.method = 'POST';
      o.body = JSON.stringify(body);
      o.contentType = 'application/json';
    }
    return o;
  }

  function discover(host) {
    try {
      var m = /https:\/\/[a-z0-9.-]+\/api(?=["\\/])/i.exec(host.getString(SITE + '/listening'));
      return m ? m[0] : null;
    } catch (e) { return null; }
  }

  function call(host, path, body, allowEmpty) {
    var tried = {}, last = null;
    var list = [working || host.getPref('base')].concat(BASES);
    for (var i = 0; i <= list.length; i++) {
      var base = i < list.length ? list[i] : discover(host);
      if (!base || tried[base]) continue;
      tried[base] = true;
      try {
        var text = host.getString(base + '/h5/listening/' + path, options(host, body));
        if (!text.trim() && allowEmpty) return {};
        var json = parseJson(text);
        if (json && json.error) throw new Error(str(json, 'message') || '接口返回错误');
        if (working !== base) { working = base; host.setPref('base', base); }
        return json;
      } catch (e) {
        if (e && e.cancelled) throw e;
        last = e;
      }
    }
    throw new Error('听友听书接口暂时无法访问：' + (last ? last.message : '无可用网关'));
  }

  function albumId(url) {
    var m = /album\/(\d+)/.exec(url);
    if (!m) throw new Error('不认识的专辑地址：' + url);
    return m[1];
  }

  function toBook(a) {
    var count = int(a, 'count');
    return {
      coverUrl: Shun.httpsUrl(str(a, 'cover_url')),
      bookUrl: SITE + '/listening/album/' + str(a, 'id'),
      title: Shun.cleanHtml(str(a, 'title')),
      author: str(a, 'author').trim(),
      artist: str(a, 'teller').trim(),
      intro: Shun.cleanHtml(str(a, 'intro') || str(a, 'description') || str(a, 'synopsis')),
      status: (int(a, 'status') === 0 ? '已完结' : '连载中') + (count > 0 ? ' · ' + count + ' 集' : '')
    };
  }

  var SORTS = { '综合排序': 'comprehensive', '播放最多': 'popular', '最近更新': 'updated', '最新发布': 'new' };

  registerSource({
    id: 'a6d1c3f08b2e4759b8e0f4a27c915d36',
    name: '听友听书',
    url: SITE + '/listening',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n有声小说和名家评书非常全，更新快。采用官方 JSON 接口，免登录直连，全本目录单次秒加载。',
    config: [{ type: 'select', key: 'sort', label: '分类排序方式', default: '播放最多', options: ['综合排序', '播放最多', '最近更新', '最新发布'] }],

    search: function (keywords, page) {
      var json = call(this.host, 'search', { keyword: keywords, page: page });
      var books = items(json, 'results').map(toBook);
      return { books: books, totalPage: json.has_more && books.length > 0 ? page + 1 : page };
    },

    categoryMenus: function () {
      var menus = [{
        title: '热播榜单',
        tabs: [['热门播放', 'hot'], ['最新上架', 'latest'], ['精品推荐', 'recommend'], ['热门连载', 'serial']].map(function (t) {
          return { title: t[0], url: 'tingyou:rank:' + t[1] + '#1' };
        })
      }];
      if (!filters) filters = call(this.host, 'filters');
      items(filters, 'categories').forEach(function (c) {
        var tabs = [{ title: '全部', url: 'tingyou:cat:category=' + str(c, 'id') + '#1' }].concat(items(c, 'types').map(function (t) {
          return { title: str(t, 'name'), url: 'tingyou:cat:type=' + str(t, 'id') + '#1' };
        }));
        menus.push({ title: str(c, 'name'), tabs: tabs });
      });
      return menus;
    },

    categoryPage: function (url) {
      var m = /^tingyou:(rank|cat):([^#]+)#(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var page = parseInt(m[3], 10), next = 'tingyou:' + m[1] + ':' + m[2] + '#' + (page + 1), books, total;
      if (m[1] === 'rank') {
        var r = call(this.host, 'rank?section=' + m[2] + '&page=' + page, undefined, true);
        books = items(r, 'items').map(toBook);
        var size = int(r, 'page_size', 30) || 30;
        total = r.has_more ? Math.max(page + 1, Math.ceil(int(r, 'total') / size)) : page;
      } else {
        var sort = SORTS[this.host.getPref('sort', '播放最多')] || 'popular';
        var c = call(this.host, 'category?sort=' + sort + '&' + m[2] + '&page=' + page, undefined, true);
        books = items(c, 'data').map(toBook);
        total = Math.max(page, int(c, 'pages', page));
      }
      if (books.length === 0) total = page;
      return { books: books, currentPage: page, totalPage: total, nextUrl: page < total ? next : null };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var id = albumId(bookUrl);
      var a = call(this.host, 'album/' + id);
      if (a.available === false) throw new Error('这本书已经下架了');
      var detail = toBook(a);
      detail.episodes = [];
      if (loadEpisodes) {
        var c = call(this.host, 'chapters/' + id);
        detail.episodes = items(c, 'chapters').map(function (ch) {
          return {
            title: Shun.cleanChapterTitle(str(ch, 'title'), detail.title) || ('第 ' + int(ch, 'index') + ' 集'),
            url: SITE + '/listening/album/' + id + '#' + int(ch, 'index'),
            isFree: true
          };
        });
      }
      return detail;
    },

    audio: function (url) {
      var m = /album\/(\d+)#(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的章节地址：' + url);
      var json = call(this.host, 'play', { album_id: m[1], chapter_idx: parseInt(m[2], 10) });
      var play = str(json, 'play_url');
      if (!play) throw new Error(str(json, 'detail') || str(json, 'message') || '没有拿到播放地址');
      return Shun.httpsUrl(play);
    }
  });
})();

// ---------- 2. 云图有声（yuntuys.com）：5星正版有声书平台，章节直带 MP3 播放直链 + 6路并发翻页 ----------
(function () {
  var API = 'http://open-service.yuntuys.com/api/w_ys/book/';
  var WECHAT = 'wechat:07955551-706c-4259-9aa0-db4627dfca57';

  function parseBook(i) {
    return {
      coverUrl: Shun.httpsUrl(str(i, 'cover')),
      bookUrl: str(i, 'bookId'),
      title: Shun.cleanHtml(str(i, 'bookName')),
      author: str(i, 'authorName'),
      artist: str(i, 'anchorName'),
      status: '共 ' + int(i, 'chapters') + ' 章',
      intro: Shun.cleanHtml(str(i, 'summary'))
    };
  }
  function chaptersUrl(bookId, p) { return API + 'getChapters/' + WECHAT + '/' + bookId + '/true/asc?pageSize=200&pageNum=' + p; }
  function parseChapters(q) {
    return items(q, 'list').map(function (i) {
      return { title: Shun.cleanChapterTitle(str(i, 'name'), ''), url: Shun.httpsUrl(str(i, 'audioUrl')), isFree: true };
    });
  }

  registerSource({
    id: 'ab0a5474cd6a40e3ba65045addad390a',
    name: '云图有声',
    url: 'http://yuntuwechat.yuntuys.com/home',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n正版有声书平台，涵盖畅销小说、悬疑推理、广播剧、经典文学、历史少儿等，全集免登录直链秒播。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var data = this.host.getJson(API + 'search/' + WECHAT + '/' + Shun.enc(keywords) + '?pageSize=20&pageNum=' + page).data;
      return { books: items(data, 'list').map(parseBook), totalPage: Math.max(1, int(data, 'totalPage')) };
    },

    categoryMenus: function () {
      function menu(title, list) {
        return {
          title: title,
          tabs: list.map(function (p) { return { title: p[0], url: API + 'getBookListByType/' + WECHAT + '/' + p[1] + '?pageNum=1&pageSize=20' }; })
        };
      }
      return [
        menu('畅销小说', [['悬疑推理', 142], ['现代都市', 143], ['怪奇物语', 144], ['侠义江湖', 335], ['科学幻想', 139], ['国风古韵', 137], ['官场商战', 140], ['军事谍战', 141], ['青春校园', 138]]),
        menu('特色精选', [['豆瓣高分', 125], ['广播剧', 126], ['影视同期', 127], ['听见真知', 124], ['远读重洋', 571]]),
        menu('经典文学', [['世界名著', 131], ['中国文学', 132], ['国学经典', 134], ['外国文学', 133], ['诗词散文', 135], ['人物传记', 136]]),
        menu('文化历史', [['古代历史', 165], ['近现代史', 166], ['世界历史', 167], ['传奇史话', 168], ['民俗文化', 161], ['哲学思想', 164]]),
        menu('少儿教育', [['儿童文学', 152], ['童话名著', 153], ['国学启蒙', 154], ['百科知识', 156]])
      ];
    },

    categoryPage: function (url) {
      var data = this.host.getJson(url).data;
      var current = int(data, 'pageNumber', 1);
      var total = Math.max(current, int(data, 'totalPage', 1));
      return {
        books: items(data, 'list').map(parseBook),
        currentPage: current,
        totalPage: total,
        nextUrl: current < total ? url.replace(/pageNum=\d+/, 'pageNum=' + (current + 1)) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      if (!loadEpisodes) return { episodes: [] };
      var host = this.host;
      var query = at(host.getJson(chaptersUrl(bookUrl, 1)), 'data.pageQuery');
      var total = int(query, 'totalPage', 1);
      var list = parseChapters(query);
      if (loadFullPages && total > 1) {
        try {
          var urls = [];
          for (var p = 2; p <= total; p++) urls.push(chaptersUrl(bookUrl, p));
          for (var i = 0; i < urls.length; i += 6) {
            var batch = urls.slice(i, i + 6);
            host.progress(Math.min(i + batch.length + 1, total) + ' / ' + total);
            host.getStrings(batch, {}, 6).forEach(function (txt) {
              if (!txt) return;
              try { list = list.concat(parseChapters(at(parseJson(txt), 'data.pageQuery'))); } catch (e) {}
            });
          }
        } finally {
          host.progress(null);
        }
      }
      return { episodes: list };
    }
  });
})();

// ---------- 3. 博看有声（bookan.com.cn）：5星国家数字图书馆有声书，MP3 直链 + 6路并发翻页 ----------
(function () {
  var INSTANCE = '25304';
  var lastPages = {};

  function unitsUrl(bookUrl, p) {
    return 'https://api.bookan.com.cn/voice/album/units?album_id=' + bookUrl + '&page=' + p + '&num=200&order=1';
  }
  function parseUnits(data) {
    return items(data, 'list').map(function (i) {
      return { title: Shun.cleanChapterTitle(str(i, 'title'), ''), url: Shun.httpsUrl(str(i, 'file')), isFree: true };
    });
  }

  registerSource({
    id: 'c98a21452583434da5cfef8be16b71d6',
    name: '博看有声',
    url: 'https://voicewk.bookan.com.cn/25303/index',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n图书馆正版数字有声资源，涵盖历史小说、国学经典、相声评书、文学名著、人文社科，免登录直链播放。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var host = this.host, books = [], failed = 0, seen = {};
      var known = lastPages[keywords] || (lastPages[keywords] = {});
      var types = ['book', 'album'];
      types.forEach(function (type) {
        if (known[type] !== undefined && page > known[type]) return;
        try {
          var json = host.getJson('https://es.bookan.com.cn/api/v3/voice/' + type + '?instanceId=' + INSTANCE + '&keyword=' + Shun.enc(keywords) +
            '&pageNum=' + page + '&limitNum=20');
          known[type] = int(json, 'data.last_page', 0);
          items(json, 'data.list').forEach(function (i) {
            var id = str(i, 'id');
            if (!id || seen[id]) return;
            seen[id] = true;
            books.push({
              coverUrl: Shun.httpsUrl(str(i, 'cover')),
              bookUrl: id,
              title: Shun.cleanHtml(str(i, 'name')),
              status: int(i, 'total') > 0 ? ('共 ' + int(i, 'total') + ' 章') : '正版有声'
            });
          });
        } catch (e) {
          if (e && e.cancelled) throw e;
          failed++;
        }
      });
      if (failed === types.length) throw new Error('博看有声搜索失败，请稍后再试');
      return { books: books, totalPage: Math.max(page, known.book || 0, known.album || 0) };
    },

    categoryMenus: function () {
      function tabs(type, list) {
        return list.map(function (p) {
          return { title: p[0], url: 'https://api.bookan.com.cn/voice/' + type + '/list?instance_id=' + INSTANCE + '&page=1&category_id=' + p[1] + '&num=24' };
        });
      }
      return [
        {
          title: '有声图书',
          tabs: tabs('book', [
            ['历史小说', 1312], ['经典必读', 1314], ['相声评书', 1319], ['故事会', 1303], ['国学经典', 1320],
            ['文学文艺', 1306], ['商业财经', 1315], ['心理哲学', 1310], ['青春励志', 1307], ['少年读物', 1305],
            ['儿童文学', 1304], ['科技科普', 1313], ['社会观察', 1318], ['音乐戏曲', 1317]
          ])
        },
        {
          title: '精选专辑',
          tabs: tabs('album', [
            ['文史军事', 10], ['人文社科', 8], ['休闲娱乐', 5], ['财经科技', 6], ['少儿学堂', 9],
            ['健康养生', 4], ['投资理财', 11], ['自我提升', 17]
          ])
        }
      ];
    },

    categoryPage: function (url) {
      var data = this.host.getJson(url).data;
      var current = int(data, 'current_page', 1), total = int(data, 'last_page', 1);
      var books = items(data, 'list').map(function (i) {
        return {
          coverUrl: Shun.httpsUrl(str(i, 'cover')),
          bookUrl: str(i, 'id'),
          title: Shun.cleanHtml(str(i, 'name')),
          status: '共 ' + int(i, 'total') + ' 章'
        };
      });
      return { books: books, currentPage: current, totalPage: total, nextUrl: current < total ? url.replace(/page=\d+/, 'page=' + (current + 1)) : null };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      if (!loadEpisodes) return { episodes: [] };
      var host = this.host;
      var data = host.getJson(unitsUrl(bookUrl, 1)).data;
      var total = int(data, 'last_page', 1);
      var list = parseUnits(data);
      if (loadFullPages && total > 1) {
        try {
          var urls = [];
          for (var p = 2; p <= total; p++) urls.push(unitsUrl(bookUrl, p));
          for (var i = 0; i < urls.length; i += 6) {
            var batch = urls.slice(i, i + 6);
            host.progress(Math.min(i + batch.length + 1, total) + ' / ' + total);
            host.getStrings(batch, {}, 6).forEach(function (txt) {
              if (!txt) return;
              try { list = list.concat(parseUnits(parseJson(txt).data)); } catch (e) {}
            });
          }
        } finally {
          host.progress(null);
        }
      }
      return { episodes: list };
    }
  });
})();

// ---------- 4. 懒人听书（m.lrts.me）：正版有声小说 JSON 接口 + 6路并发章节加载 + 精准登录校验 ----------
(function () {
  var EPISODE_PAGE_SIZE = 50;
  var CATEGORY_PAGE_SIZE = 20;
  var categoryBookIds = {};

  function parseBook(node) {
    var cover = Shun.httpsUrl(str(node, 'cover'));
    if (cover.length > 0 && cover.indexOf('180') < 0) {
      var dot = cover.lastIndexOf('.');
      if (dot > 0) cover = cover.substring(0, dot) + '_180x254' + cover.substring(dot);
    }
    var title = Shun.cleanHtml(str(node, 'name'));
    var tags = str(node, 'tags');
    if (tags.indexOf('VIP') >= 0) title = '[VIP] ' + title;
    else if (tags.indexOf('精品') >= 0) title = '[精品] ' + title;
    var finished = int(node, 'state') === 2;
    var sections = int(node, 'sections');
    var intro = str(node, 'recReason');
    if (intro.length === 0 || intro === 'null') intro = str(node, 'desc');
    return {
      coverUrl: cover,
      bookUrl: 'https://m.lrts.me?' + str(node, 'id'),
      title: title,
      author: str(node, 'author'),
      artist: str(node, 'announcer'),
      intro: Shun.cleanHtml(intro),
      status: (finished ? '完本' : '连载') + (sections > 0 ? ' · ' + sections + ' 集' : '')
    };
  }

  function parseQuery(url) {
    var q = {}, i = url.indexOf('?');
    if (i < 0) return q;
    url.substring(i + 1).split('&').forEach(function (p) {
      var k = p.split('=')[0];
      if (k && !(k in q)) q[k] = decodeURIComponent(p.substring(k.length + 1));
    });
    return q;
  }

  function menuUrl(bookId, page) {
    return 'https://m.lrts.me/ajax/getBookMenu?bookId=' + bookId + '&pageNum=' + page + '&pageSize=' + EPISODE_PAGE_SIZE + '&sortType=0';
  }

  function getMenu(host, bookId, page) {
    var json = host.getJson(menuUrl(bookId, page));
    if (!json.list && str(json, 'msg')) throw new Error(str(json, 'msg'));
    return json;
  }

  function parseEpisodes(json, bookId, offset) {
    return items(json, 'list').map(function (track, i) {
      var isFree = int(track, 'payType') === 0;
      return {
        title: Shun.cleanHtml(str(track, 'name')),
        isFree: isFree,
        url: isFree
          ? 'https://m.lrts.me/ajax/getPlayPath?entityId=' + bookId + '&entityType=3&opType=1&sections=[' + int(track, 'section') + ']&type=0'
          : 'https://m.lrts.me/player?index=' + (offset + i) + '&entityType=3&sonId=' + str(track, 'id') + '&id=' + bookId
      };
    });
  }

  registerSource({
    id: '4a3ed84e5cf841609ed4d7f790fc7fbf',
    name: '懒人听书',
    url: 'https://m.lrts.me',
    group: '精品有声',
    description: '推荐指数:4星 ⭐⭐⭐⭐\n正版有声书源，免费章节免登录直连播放；带 [VIP] / [精品] 标识的书籍可在书源管理页登录懒人账号后收听。',
    multipleEpisodePages: true,
    loginUrl: 'https://m.lrts.me/user',

    // 新增真实登录态校验，避免未登录时因访客 Cookie 误报为已登录
    checkLogin: function () {
      var ck = typeof this.host.cookies === 'function' ? String(this.host.cookies('https://m.lrts.me/') || '') : '';
      if (/(?:^|;\s*)(?:uid|token|lrts_uid)=[1-9a-zA-Z]/.test(ck)) {
        return '懒人账号已登录';
      }
      var html = this.host.getString('https://m.lrts.me/user');
      if (html.indexOf('退出登录') >= 0 || html.indexOf('logout') >= 0) {
        return '懒人账号已登录';
      }
      throw new Error('还没有登录懒人听书');
    },

    search: function (keywords, page) {
      var result = at(this.host.getJson('https://m.lrts.me/ajax/search?keyWord=' + Shun.enc(keywords) + '&pageSize=40&pageNum=' + page + '&searchOption=1'), 'data.bookResult');
      return { books: items(result, 'list').map(parseBook), totalPage: Math.max(Math.ceil(int(result, 'count') / 40), 1) };
    },

    categoryMenus: function () {
      function menu(title, list) {
        return {
          title: title,
          tabs: list.map(function (p) {
            return { title: p[0], url: 'https://m.lrts.me/ajax/getResourceList?dsize=' + CATEGORY_PAGE_SIZE + '&entityId=' + p[1] + '&entityType=1&pageNum=1&showFilters=1' };
          })
        };
      }
      return [
        menu('有声小说', [['玄幻奇幻', 11], ['都市传说', 8], ['穿越架空', 3109], ['武侠仙侠', 14], ['青春校园', 3106],
          ['历史幻想', 12], ['科幻空间', 3021], ['网游竞技', 9042], ['热血军事', 9041], ['官场商战', 44]]),
        menu('人文社科', [['人物传记', 17], ['纪实传奇', 3063], ['心理百科', 9045], ['科学科普', 9046], ['文艺文化', 9044], ['公开课', 109]]),
        menu('商业财经', [['投资理财', 3059], ['商业智慧', 3057], ['管理营销', 16], ['创业', 9048]]),
        menu('少儿曲艺', [['儿童文学', 3027], ['少儿名著', 9245], ['国学启蒙', 9031], ['戏曲名家', 9060], ['鼓书琴书', 67]])
      ];
    },

    categoryPage: function (url) {
      var query = parseQuery(url);
      var entityId = query.entityId || '';
      var json = this.host.getJson(url);
      var useAlbums = int(json, 'albumCount') > 0;
      var books = items(json, useAlbums ? 'albums' : 'books').map(parseBook);
      var currentPage;
      if (!('bookIds' in query)) {
        currentPage = 1;
        categoryBookIds[entityId] = items(json, useAlbums ? 'albumIds' : 'bookIds');
      } else {
        currentPage = parseInt(query.page, 10) || 2;
      }
      var nextUrl = null, ids = categoryBookIds[entityId];
      if (ids) {
        var from = currentPage * CATEGORY_PAGE_SIZE;
        if (from < ids.length) {
          nextUrl = 'https://m.lrts.me/ajax/getResourceList?dsize=' + CATEGORY_PAGE_SIZE + '&entityId=' + entityId + '&entityType=0&pageNum=0&showFilters=0' +
            '&page=' + (currentPage + 1) + '&bookIds=[' + ids.slice(from, from + CATEGORY_PAGE_SIZE).join(',') + ']';
        }
      }
      return { books: books, currentPage: currentPage, totalPage: nextUrl ? currentPage + 1 : currentPage, nextUrl: nextUrl };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var bookId = bookUrl.split('?').pop();
      var episodes = [];
      if (loadEpisodes) {
        var first = getMenu(host, bookId, 1);
        var pageCount = Math.ceil(int(first, 'sections') / EPISODE_PAGE_SIZE);
        episodes = parseEpisodes(first, bookId, 0);
        if (loadFullPages && pageCount > 1) {
          try {
            var urls = [];
            for (var p = 2; p <= pageCount; p++) urls.push(menuUrl(bookId, p));
            for (var i = 0; i < urls.length; i += 6) {
              var batch = urls.slice(i, i + 6);
              host.progress(Math.min(i + batch.length + 1, pageCount) + ' / ' + pageCount);
              host.getStrings(batch, {}, 6).forEach(function (txt) {
                if (!txt) return;
                try {
                  episodes = episodes.concat(parseEpisodes(parseJson(txt), bookId, episodes.length));
                } catch (e) {}
              });
            }
          } finally {
            host.progress(null);
          }
        }
      }
      var info = host.getJson('https://m.lrts.me/ajax/getBookInfo?id=' + bookId);
      return {
        episodes: episodes,
        intro: Shun.cleanHtml(str(info, 'extraInfos.0.content')),
        artist: str(info, 'announcer'),
        author: str(info, 'author'),
        coverUrl: Shun.httpsUrl(str(info, 'bestCover'))
      };
    },

    audio: function (url) {
      if (url.indexOf('getPlayPath') >= 0) {
        var json = this.host.getJson(url);
        var path = str(json, 'list.0.path');
        if (!path) throw new Error(str(json, 'msg') || '无法获取音频地址');
        return Shun.httpsUrl(path);
      }
      return this.host.sniff(url);
    }
  });
})();
