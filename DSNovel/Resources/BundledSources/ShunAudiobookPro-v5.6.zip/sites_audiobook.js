// ---------- 极速直链有声小说站合集 (sites_audiobook.js) ----------
// 已剔除原 sites.js / cms.js / zblog.js / ytysxs.js 中的：
// - 电台网(广播)、声音巴士(播客)
// - 乐听吧/米听书/囧贼听书/一夜幻听(每次搜索强制 6s 延迟与图形验证码)
// - 爱听书(每翻一页强制等待 6 秒限流)、13听书网(纯 WebView 嗅探)
// - 评书随身听/相声随身听(Cloudflare 强五秒盾 + 全站抓取建索引超时)
// - 念音网/有听网/悦听吧(每次切集需 WebView 渲染等待数秒)、单田芳评书网/悦听有声书(不支持搜索)、听中国(分类残缺)
// 仅保留实测在线极速响应、支持搜索且提供音频直链的优质有声小说站：听书网（已归入「精品有声」分组）。起点有声网、29听书网已移除。

// ---------- 1. 听书网（手机版 m.tingshuwang.cc）：热门网文多人有声剧，章节一页列完，音频直链秒播 ----------
(function () {
  var SITE = 'https://m.tingshuwang.cc';

  function parseBooks(doc) {
    return doc.select('ul.m-book-list > li').map(function (li) {
      var a = li.first('h5 a');
      var latest = li.first('.cover em').text();
      return {
        coverUrl: li.first('.cover img').absUrl('src'),
        bookUrl: a.absUrl('href'),
        title: Shun.cleanHtml(a.text()),
        artist: li.first('.author a').text(),
        intro: Shun.cleanHtml(li.first('p.intro').text()),
        status: [li.first('h5 em').text(), latest].filter(function (s) { return s; }).join(' · ')
      };
    }).filter(function (b) { return b.bookUrl && b.title; });
  }

  registerSource({
    id: 'f2b9d4a61c7e48f3a5d08e3b7c1a9d54',
    name: '听书网',
    url: SITE + '/',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n收录大量爆款网文多人有声剧（诡秘之主、蛊真人、深海余烬、吞噬星空、明朝败家子等），章节单页秒出，音频直链无需登录。',
    coverHeaders: Shun.coverReferer('tingshuwang.cc', SITE + '/'),

    search: function (keywords, page) {
      if (page > 1) return { books: [], totalPage: 1 };
      return {
        books: parseBooks(Shun.getDoc(this.host, SITE + '/so/' + Shun.enc(keywords) + '/', false, SITE + '/')),
        totalPage: 1
      };
    },

    categoryMenus: function () {
      var cats = [
        ['全部有声', ''], ['热门连载', 'lianzai/'], ['经典完结', 'wanjie/'],
        ['玄幻武侠', 'xuanhuanwuxia/'], ['恐怖悬疑', 'kongbuxuanyi/'], ['都市言情', 'dushiyanqing/'],
        ['职场商战', 'zhichangshangzhan/'], ['推理小说', 'tuilixiaoshuo/'], ['军事历史', 'junshilishi/'],
        ['网游竞技', 'wangyoujingji/'], ['综艺娱乐', 'zongyiyule/']
      ];
      return [{
        title: '有声小说',
        tabs: cats.map(function (c) { return { title: c[0], url: SITE + '/book/' + c[1] + 'index.html' }; })
      }];
    },

    categoryPage: function (url) {
      var doc = Shun.getDoc(this.host, url, false, SITE + '/');
      var m = /(\d+)\s*\/\s*(\d+)/.exec(doc.first('.mpages .page-info').text());
      var current = m ? parseInt(m[1], 10) : 1, total = m ? parseInt(m[2], 10) : 1;
      var next = doc.first('.mpages a.next').absUrl('href');
      return {
        books: parseBooks(doc),
        currentPage: current,
        totalPage: total,
        nextUrl: current < total && /^http/.test(next) ? next : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var doc = Shun.getDoc(this.host, bookUrl, false, SITE + '/');
      var title = Shun.cleanHtml(doc.first('h1.bookname').text());
      var intro = doc.first('.book-intro').text();
      var head = doc.first('.book-intro .intro-title').text(), tail = doc.first('.book-intro p.other').text();
      if (head && intro.indexOf(head) === 0) intro = intro.substring(head.length);
      if (tail && intro.lastIndexOf(tail) >= 0) intro = intro.substring(0, intro.lastIndexOf(tail));
      var detail = {
        title: title,
        coverUrl: doc.first('.book-details .cover img').absUrl('src'),
        author: doc.first('.book-details .author a').text(),
        artist: doc.first('.book-details .announcer a').text(),
        status: doc.first('.book-details .status').text(),
        intro: Shun.cleanHtml(intro),
        episodes: []
      };
      if (loadEpisodes) {
        var list = doc.select('ul.chapter-list-data > li > a').map(function (a) {
          var name = Shun.cleanChapterTitle(a.text(), title);
          return { title: name, url: a.absUrl('href'), isFree: true };
        }).filter(function (e) { return e.url; });
        function id(e) { return regexInt(e.url, /\/(\d+)\.html$/, 0); }
        if (list.length > 1 && id(list[0]) > id(list[list.length - 1])) list.reverse();
        detail.episodes = list;
      }
      return detail;
    },

    audio: function (url) {
      var html = this.host.getString(url, { headers: { Referer: SITE + '/' } });
      var m = /videourl\s*:\s*'([^']*)'/.exec(html), type = /videotype\s*:\s*'([^']*)'/.exec(html);
      var audio = m ? m[1].trim() : '';
      if (!/^https?:\/\//.test(audio) || (type && type[1] === 'tc')) {
        throw new Error('该章节暂未提供直链音频，请尝试换源收听');
      }
      return { url: audio, headers: { Referer: SITE + '/' } };
    }
  });
})();
