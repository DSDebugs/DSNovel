// ---------- 极速直链有声小说站 (sites_audiobook.js v5.6.4) ----------
// 听书网（手机版 m.tingshuwang.cc）：已移除失效的「综艺娱乐」分类，加固封面懒加载、简介清洗与音频提取正则
(function () {
  var SITE = 'https://m.tingshuwang.cc';

  function extractCover(imgNode) {
    if (!imgNode || !imgNode.exists()) return '';
    var raw = imgNode.absUrl('data-original') || imgNode.absUrl('data-src') || imgNode.absUrl('src')
      || imgNode.attr('data-original') || imgNode.attr('data-src') || imgNode.attr('src');
    return Shun.cleanCover(raw);
  }

  function parseBooks(doc) {
    return doc.select('ul.m-book-list > li').map(function (li) {
      var a = li.first('h5 a');
      var latest = li.first('.cover em').text();
      return {
        coverUrl: extractCover(li.first('.cover img')),
        bookUrl: a.absUrl('href'),
        title: Shun.cleanHtml(a.text()),
        artist: li.first('.author a').text().trim(),
        intro: Shun.stripIntroPrefix(li.first('p.intro').text()),
        status: [li.first('h5 em').text(), latest].filter(function (s) { return s; }).join(' · ')
      };
    }).filter(function (b) { return b.bookUrl && b.title; });
  }

  registerSource({
    id: 'f2b9d4a61c7e48f3a5d08e3b7c1a9d54',
    name: '听书网',
    url: SITE + '/',
    group: '精品有声',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n收录大量爆款网文多人有声剧（诡秘之主、蛊真人、深海余烬、吞噬星空、明朝败家子等），章节单页秒出，音频直链无需登录。',
    coverHeaders: Shun.coverReferer('tingshuwang.cc', SITE + '/'),

    search: function (keywords, page) {
      var p = page || 1;
      var url = p <= 1
        ? (SITE + '/so/' + Shun.enc(keywords) + '/')
        : (SITE + '/so/' + Shun.enc(keywords) + '/page/' + p + '/');
      var doc = Shun.getDoc(this.host, url, false, SITE + '/');
      var m = /(\d+)\s*\/\s*(\d+)/.exec(doc.first('.mpages .page-info').text());
      var total = m ? parseInt(m[2], 10) : 1;
      return {
        books: parseBooks(doc),
        totalPage: Math.max(1, total)
      };
    },

    categoryMenus: function () {
      var cats = [
        ['全部有声', ''], ['热门连载', 'lianzai/'], ['经典完结', 'wanjie/'],
        ['玄幻武侠', 'xuanhuanwuxia/'], ['恐怖悬疑', 'kongbuxuanyi/'], ['都市言情', 'dushiyanqing/'],
        ['职场商战', 'zhichangshangzhan/'], ['推理小说', 'tuilixiaoshuo/'], ['军事历史', 'junshilishi/'],
        ['网游竞技', 'wangyoujingji/']
      ];
      return [{
        title: '有声小说',
        tabs: cats.map(function (c) { return { title: c[0], url: SITE + '/book/' + c[1] + 'index.html' }; })
      }];
    },

    categoryPage: function (url) {
      var doc = Shun.getDoc(this.host, url, false, SITE + '/');
      var m = /(\d+)\s*\/\s*(\d+)/.exec(doc.first('.mpages .page-info').text());
      var current = m ? parseInt(m[1], 10) : 1, total = m ? parseInt(m[2], 10) : 1;
      var next = doc.first('.mpages a.next').absUrl('href');
      return {
        books: parseBooks(doc),
        currentPage: current,
        totalPage: total,
        nextUrl: current < total && /^http/.test(next) ? next : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var doc = Shun.getDoc(this.host, bookUrl, false, SITE + '/');
      var title = Shun.cleanHtml(doc.first('h1.bookname').text());
      var intro = doc.first('.book-intro').text();
      var head = doc.first('.book-intro .intro-title').text(), tail = doc.first('.book-intro p.other').text();
      if (head && intro.indexOf(head) === 0) intro = intro.substring(head.length);
      if (tail && intro.lastIndexOf(tail) >= 0) intro = intro.substring(0, intro.lastIndexOf(tail));
      var author = doc.first('.book-details .author a').text().trim();
      var announcer = doc.first('.book-details .announcer a').text().trim();
      var detail = {
        title: title,
        coverUrl: extractCover(doc.first('.book-details .cover img')),
        author: author,
        artist: announcer || author,
        status: doc.first('.book-details .status').text().trim(),
        intro: Shun.stripIntroPrefix(intro),
        episodes: []
      };
      if (loadEpisodes) {
        var list = doc.select('ul.chapter-list-data > li > a').map(function (a) {
          var name = Shun.cleanChapterTitle(a.text(), title);
          return { title: name, url: a.absUrl('href'), isFree: true };
        }).filter(function (e) { return e.url; });
        function id(e) { return regexInt(e.url, /\/(\d+)\.html$/, 0); }
        if (list.length > 1 && id(list[0]) > id(list[list.length - 1])) list.reverse();
        detail.episodes = list;
      }
      return detail;
    },

    audio: function (url) {
      var html = this.host.getString(url, { headers: { Referer: SITE + '/' } });
      var m = /videourl\s*:\s*['"]([^'"]+)['"]/.exec(html);
      var type = /videotype\s*:\s*['"]([^'"]+)['"]/.exec(html);
      var audio = m ? Shun.httpsUrl(m[1].trim()) : '';
      if (!/^https?:\/\//.test(audio) || (type && type[1] === 'tc')) {
        throw new Error('该章节暂未提供直链音频，请稍后重试或选择其他版本');
      }
      return { url: audio, headers: { Referer: SITE + '/' } };
    }
  });
})();
