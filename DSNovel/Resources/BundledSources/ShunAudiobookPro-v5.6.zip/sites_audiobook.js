// ---------- 极速直链有声小说站合集 (sites_audiobook.js) ----------
// 已剔除原 sites.js / cms.js / zblog.js / ytysxs.js 中的：
// - 电台网(广播)、声音巴士(播客)
// - 乐听吧/米听书/囧贼听书/一夜幻听(每次搜索强制 6s 延迟与图形验证码)
// - 爱听书(每翻一页强制等待 6 秒限流)、13听书网(纯 WebView 嗅探)
// - 评书随身听/相声随身听(Cloudflare 强五秒盾 + 全站抓取建索引超时)
// - 念音网/有听网/悦听吧(每次切集需 WebView 渲染等待数秒)、单田芳评书网/悦听有声书(不支持搜索)、听中国(分类残缺)
// 仅保留实测在线极速响应、支持搜索且提供音频直链的 3 大优质有声小说站：听书网、起点有声网、29听书网。

// ---------- 1. 听书网（手机版 m.tingshuwang.cc）：热门网文多人有声剧，章节一页列完，音频直链秒播 ----------
(function () {
  var SITE = 'https://m.tingshuwang.cc';

  function parseBooks(doc) {
    return doc.select('ul.m-book-list > li').map(function (li) {
      var a = li.first('h5 a');
      var latest = li.first('.cover em').text();
      return {
        coverUrl: li.first('.cover img').absUrl('src'),
        bookUrl: a.absUrl('href'),
        title: Shun.cleanHtml(a.text()),
        artist: li.first('.author a').text(),
        intro: Shun.cleanHtml(li.first('p.intro').text()),
        status: [li.first('h5 em').text(), latest].filter(function (s) { return s; }).join(' · ')
      };
    }).filter(function (b) { return b.bookUrl && b.title; });
  }

  registerSource({
    id: 'f2b9d4a61c7e48f3a5d08e3b7c1a9d54',
    name: '听书网',
    url: SITE + '/',
    group: '有声小说',
    description: '推荐指数:5星 ⭐⭐⭐⭐⭐\n收录大量爆款网文多人有声剧（诡秘之主、蛊真人、深海余烬、吞噬星空、明朝败家子等），章节单页秒出，音频直链无需登录。',
    coverHeaders: Shun.coverReferer('tingshuwang.cc', SITE + '/'),

    search: function (keywords, page) {
      if (page > 1) return { books: [], totalPage: 1 };
      return {
        books: parseBooks(Shun.getDoc(this.host, SITE + '/so/' + Shun.enc(keywords) + '/', false, SITE + '/')),
        totalPage: 1
      };
    },

    categoryMenus: function () {
      var cats = [
        ['全部有声', ''], ['热门连载', 'lianzai/'], ['经典完结', 'wanjie/'],
        ['玄幻武侠', 'xuanhuanwuxia/'], ['恐怖悬疑', 'kongbuxuanyi/'], ['都市言情', 'dushiyanqing/'],
        ['职场商战', 'zhichangshangzhan/'], ['推理小说', 'tuilixiaoshuo/'], ['军事历史', 'junshilishi/'],
        ['网游竞技', 'wangyoujingji/'], ['综艺娱乐', 'zongyiyule/']
      ];
      return [{
        title: '有声小说',
        tabs: cats.map(function (c) { return { title: c[0], url: SITE + '/book/' + c[1] + 'index.html' }; })
      }];
    },

    categoryPage: function (url) {
      var doc = Shun.getDoc(this.host, url, false, SITE + '/');
      var m = /(\d+)\s*\/\s*(\d+)/.exec(doc.first('.mpages .page-info').text());
      var current = m ? parseInt(m[1], 10) : 1, total = m ? parseInt(m[2], 10) : 1;
      var next = doc.first('.mpages a.next').absUrl('href');
      return {
        books: parseBooks(doc),
        currentPage: current,
        totalPage: total,
        nextUrl: current < total && /^http/.test(next) ? next : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var doc = Shun.getDoc(this.host, bookUrl, false, SITE + '/');
      var title = Shun.cleanHtml(doc.first('h1.bookname').text());
      var intro = doc.first('.book-intro').text();
      var head = doc.first('.book-intro .intro-title').text(), tail = doc.first('.book-intro p.other').text();
      if (head && intro.indexOf(head) === 0) intro = intro.substring(head.length);
      if (tail && intro.lastIndexOf(tail) >= 0) intro = intro.substring(0, intro.lastIndexOf(tail));
      var detail = {
        title: title,
        coverUrl: doc.first('.book-details .cover img').absUrl('src'),
        author: doc.first('.book-details .author a').text(),
        artist: doc.first('.book-details .announcer a').text(),
        status: doc.first('.book-details .status').text(),
        intro: Shun.cleanHtml(intro),
        episodes: []
      };
      if (loadEpisodes) {
        var list = doc.select('ul.chapter-list-data > li > a').map(function (a) {
          var name = Shun.cleanChapterTitle(a.text(), title);
          return { title: name, url: a.absUrl('href'), isFree: true };
        }).filter(function (e) { return e.url; });
        function id(e) { return regexInt(e.url, /\/(\d+)\.html$/, 0); }
        if (list.length > 1 && id(list[0]) > id(list[list.length - 1])) list.reverse();
        detail.episodes = list;
      }
      return detail;
    },

    audio: function (url) {
      var html = this.host.getString(url, { headers: { Referer: SITE + '/' } });
      var m = /videourl\s*:\s*'([^']*)'/.exec(html), type = /videotype\s*:\s*'([^']*)'/.exec(html);
      var audio = m ? m[1].trim() : '';
      if (!/^https?:\/\//.test(audio) || (type && type[1] === 'tc')) {
        throw new Error('该章节暂未提供直链音频，请尝试换源收听');
      }
      return { url: audio, headers: { Referer: SITE + '/' } };
    }
  });
})();

// ---------- 2 & 3. 起点有声网 (www.qdysw.com) & 29听书网 (www.ting29.com)：33TB 多人有声剧/评书直链库 ----------
function registerTing29Family(SITE, id, name, description) {
  var PAGE_SIZE = 50;
  var dirToken = null, dirTokenExpires = 0;

  function retry403(fn) {
    try { return fn(); } catch (e) {
      if (e.status !== 403) throw e;
      return fn();
    }
  }
  function getDoc(host, url, referer) {
    return retry403(function () { return Shun.getDoc(host, url, true, referer); });
  }

  function findLink(doc, texts) {
    var list = doc.select('a');
    for (var i = 0; i < list.length; i++) {
      if (texts.indexOf(list[i].text()) >= 0) return list[i].absUrl('href');
    }
    return '';
  }
  function nextPageUrl(doc) { return findLink(doc, ['下页', '下一页']); }
  function lastPage(doc) { return regexInt(findLink(doc, ['尾页']), /\/(\d+)\.html/, 1); }

  function parseBooks(doc) {
    var books = [];
    doc.select('ul.list-works > li').forEach(function (li) {
      var a = li.first('dt.list-book-dt > a');
      if (!a.exists()) return;
      var img = li.first('.list-imgbox img');
      var state = li.first('dt.list-book-dt > span').text();
      var latest = li.first('dt.list-book-dt > span > a').text();
      books.push({
        coverUrl: img.absUrl('data-original') || img.absUrl('src'),
        bookUrl: a.absUrl('href'),
        title: Shun.cleanHtml(a.text()),
        author: '',
        artist: li.select('.book-author a').map(function (e) { return e.text(); }).join(' '),
        intro: Shun.cleanHtml(li.first('dd.list-book-des').text()),
        status: [state, latest].filter(function (x) { return x.length > 0; }).join(' · ')
      });
    });
    return books;
  }

  function addEpisodes(doc, list, bookTitle) {
    doc.select('#playlist li a').forEach(function (a) {
      list.push({
        title: Shun.cleanChapterTitle(a.text(), bookTitle),
        url: a.absUrl('href'),
        isFree: true
      });
    });
  }

  function readToken(host, html) {
    var m = /reversed = "([^"]+)"/.exec(html);
    if (!m) return null;
    var code = host.base64Decode(m[1].split('').reverse().join(''));
    var t = /var token = '([^']+)'/.exec(code);
    if (!t) return null;
    var parts = host.base64Decode(t[1]).split('|');
    var expires = parts.length > 2 ? parseInt(parts[2], 10) : NaN;
    return { token: t[1], expires: isNaN(expires) ? Date.now() / 1000 + 3600 : expires };
  }

  function getDir(host, url) {
    for (var attempt = 0; attempt < 3; attempt++) {
      var token = Date.now() / 1000 < dirTokenExpires ? dirToken : null;
      var html = retry403(function () {
        return host.getString(url, { desktop: true, headers: token ? { Cookie: 'pt_guid=' + encodeURIComponent(token) } : {} });
      });
      if (html.indexOf('reversed = "') < 0) return host.parseHtml(html, url);
      var t = readToken(host, html);
      if (!t) break;
      dirToken = t.token;
      dirTokenExpires = t.expires - 300;
    }
    var rendered = host.render(url, {
      desktop: true,
      script: "(function(){return document.querySelector('#playlist li a')?'<html>'+document.documentElement.innerHTML+'</html>':'';})();"
    });
    return host.parseHtml(rendered, url);
  }

  function loadBook(host, bookUrl, known, loadEpisodes, loadFullPages) {
    var list = [];
    var doc1 = getDoc(host, bookUrl);
    var artist = [];
    doc1.select('.book-info dd').forEach(function (d) {
      if (artist.length === 0 && d.text().indexOf('演播') === 0) {
        artist = d.select('a').map(function (e) { return e.text(); });
      }
    });
    var bookTitle = Shun.cleanHtml(doc1.first('.book-info dt').text());
    var detail = {
      title: bookTitle,
      episodes: list,
      intro: Shun.cleanHtml(doc1.first('.book-des').text()),
      coverUrl: doc1.first('.book-info').parent().first('img').absUrl('data-original'),
      artist: artist.join(' ')
    };
    if (!loadEpisodes) return detail;

    if (known && known.length > 0) {
      var latest = [];
      addEpisodes(doc1, latest, bookTitle);
      latest.reverse();
      var urls = {};
      known.forEach(function (e) { urls[e.url] = true; });
      if (latest.length > 0 && urls[latest[0].url]) {
        known.forEach(function (e) { list.push(e); });
        latest.forEach(function (e) { if (!urls[e.url]) list.push(e); });
        return detail;
      }
    }

    var dirUrl = doc1.first('a.dirurl').absUrl('href');
    var doc = dirUrl.length > 0 ? getDir(host, dirUrl) : doc1;
    var seen = {}, pages = [];
    doc.select('a').forEach(function (a) {
      var u = a.absUrl('href');
      var p = regexInt(u, /[?&]page=(\d+)/, 0);
      if (p > 1 && !seen[p]) { seen[p] = true; pages.push({ url: u, page: p }); }
    });
    pages.sort(function (a, b) { return a.page - b.page; });

    var startPage = 1;
    if (known && known.length > PAGE_SIZE && pages.length > 0) {
      startPage = Math.min(Math.floor(known.length / PAGE_SIZE), pages.length) + 1;
      known.slice(0, (startPage - 1) * PAGE_SIZE).forEach(function (e) { list.push(e); });
    }
    if (startPage === 1) addEpisodes(doc, list, bookTitle);
    if (!loadFullPages) return detail;

    try {
      var page = Math.max(2, startPage);
      for (; page <= pages.length + 1; page += 6) {
        var batch = pages.slice(page - 2, page - 2 + 6);
        host.progress(Math.min(page + batch.length - 1, pages.length + 1) + ' / ' + (pages.length + 1));
        var token = Date.now() / 1000 < dirTokenExpires ? dirToken : null;
        var texts = host.getStrings(
          batch.map(function (b) { return b.url; }),
          { desktop: true, headers: token ? { Cookie: 'pt_guid=' + encodeURIComponent(token) } : {} },
          6
        );
        batch.forEach(function (b, k) {
          var ok = texts[k] !== null && texts[k].indexOf('reversed = "') < 0;
          addEpisodes(ok ? host.parseHtml(texts[k], b.url) : getDir(host, b.url), list, bookTitle);
        });
      }
    } finally {
      host.progress(null);
    }
    return detail;
  }

  registerSource({
    id: id,
    name: name,
    url: SITE,
    group: '有声小说',
    description: description,
    multipleEpisodePages: true,
    coverHeaders: Shun.coverReferer(Shun.hostOf(SITE).replace(/^www\./, ''), SITE),

    search: function (keywords, page) {
      var host = this.host;
      var doc = page > 1
        ? Shun.getDoc(host, SITE + 'search.html?searchtype=name&searchword=' + Shun.enc(keywords) + '&page=' + page, true, SITE + 'search.html')
        : host.getHtml(SITE + 'search.html', {
          desktop: true,
          method: 'POST',
          body: 'searchword=' + Shun.enc(keywords),
          headers: { Referer: SITE, Origin: SITE.replace(/\/$/, '') }
        });
      var books = parseBooks(doc);
      var more = doc.select('a').some(function (a) { return a.text() === '下一页' || a.text() === '下页'; });
      return { books: books, totalPage: more && books.length > 0 ? page + 1 : page };
    },

    categoryMenus: function () {
      function tabs(list) {
        return list.map(function (p) { return { title: p[0], url: SITE + 'book/' + p[1] + '/lastupdate.html' }; });
      }
      return [
        {
          title: '有声小说',
          tabs: tabs([
            ['全部', 'all'], ['玄幻奇幻', 'xhqh'], ['武侠仙侠', 'wxxx'], ['穿越架空', 'cyjk'], ['悬疑推理', 'xytl'],
            ['科幻竞技', 'khjj'], ['历史军事', 'lsjs'], ['现代言情', 'xdyq'], ['古代言情', 'gdyq'], ['幻想言情', 'hxyq'],
            ['青春校园', 'qcxy'], ['影视原著', 'ysyz'], ['文学名著', 'wxmz'], ['乡村生活', 'xcsh']
          ])
        },
        {
          title: '评书人文',
          tabs: tabs([
            ['长篇评书', 'pingshu'], ['相声曲艺', 'xsqy'], ['国学经典', 'gxjd'], ['名家传记', 'mjcj'],
            ['档案纪实', 'dajs'], ['博闻杂谈', 'bxzt'], ['儿童频道', 'ertong'], ['职场干货', 'zcgh'], ['自我提升', 'zwts']
          ])
        }
      ];
    },

    categoryPage: function (url) {
      var doc = getDoc(this.host, url);
      var current = regexInt(url, /\/(\d+)\.html$/);
      return {
        books: parseBooks(doc),
        currentPage: current,
        totalPage: Math.max(current, lastPage(doc)),
        nextUrl: nextPageUrl(doc)
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      return loadBook(this.host, bookUrl, null, loadEpisodes, loadFullPages);
    },

    updateEpisodes: function (bookUrl, known) {
      return loadBook(this.host, bookUrl, known, true, true);
    },

    audio: function (url) {
      var host = this.host;
      try {
        var player = getDir(host, url).first('iframe[src*="player.html"]').absUrl('src');
        if (player) {
          var html = host.getString(player, { desktop: true, headers: { Referer: url } });
          if (html.indexOf('reversed = "') >= 0) html = getDir(host, player).outerHtml();
          var m = /(?:mp3|m4a|oga|wav)\s*:\s*'([^']*)'\s*\+\s*(\w+)/.exec(html);
          if (m) {
            var tail = new RegExp(m[2] + "\\s*=\\s*'([^']*)'").exec(html);
            var audio = m[1] + (tail ? tail[1] : '');
            if (/^https?:\/\//.test(audio)) {
              return audio.replace(/^https:\/\/([^\/]*\.ysxs\.top\/)/, 'http://$1');
            }
          }
        }
      } catch (e) { if (e && e.cancelled) throw e; }
      var sniffed = host.sniff(url, { desktop: true });
      return typeof sniffed === 'string' ? sniffed.replace(/^https:\/\/([^\/]*\.ysxs\.top\/)/, 'http://$1') : sniffed;
    }
  });
}

registerTing29Family(
  'https://www.qdysw.com/',
  '3b7d5e0a9c1f4826a4e7d2c8f6b10e95',
  '起点有声网',
  '推荐指数:5星 ⭐⭐⭐⭐⭐\n33.4TB 海量有声小说、多人精品有声剧、长篇评书、相声曲艺、历史国学，分类极细，音频直链无需登录。'
);

registerTing29Family(
  'https://www.ting29.com/',
  'd4a8f1c63e9b47d2b5a0c7e91f3d6b28',
  '29听书网',
  '推荐指数:4星 ⭐⭐⭐⭐\n有声小说、多人有声剧、长篇评书、相声曲艺、儿童国学，更新快，音频直链无需登录。'
);
