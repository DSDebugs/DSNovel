// ---------- 番茄畅听（DSNovel v5.6.4 并发提速与容灾优化版） ----------
(function () {
  var FQ_SITE = 'https://fanqienovel.com';
  var FQ_SEARCH_API = 'https://api.fanqiesdk.com/api/novel/channel/homepage/search/search/v1/';
  var FQ_CATEGORY_API = 'https://novel.snssdk.com/api/novel/channel/homepage/new_category/book_list/v1/';
  var FQ_APP_UA = 'com.ss.android.article.news/13400 (Linux; U; Android 13; zh_CN; Pixel 7; Build/TD1A.220804.031)';
  var XMLY_FREE_SEARCH = 'https://search.ximalaya.com/front/v1';

  function mapTingyouBook(a) {
    var count = int(a, 'count', 0);
    var author = str(a, 'author').trim();
    var teller = str(a, 'teller').trim();
    return {
      title: Shun.cleanHtml(str(a, 'title')),
      author: author,
      artist: teller || author || '番茄精品有声',
      intro: Shun.stripIntroPrefix(str(a, 'intro') || str(a, 'description') || str(a, 'synopsis')),
      coverUrl: Shun.cleanCover(str(a, 'cover_url')),
      bookUrl: 'fq://tingyou/' + str(a, 'id'),
      status: (int(a, 'status', 0) === 0 ? '已完结' : '连载中') + (count > 0 ? ' · ' + count + ' 章' : '')
    };
  }

  function mapYuntuBook(i) {
    var count = int(i, 'chapters', 0);
    var author = str(i, 'authorName').trim();
    var anchor = str(i, 'anchorName').trim();
    return {
      title: Shun.cleanHtml(str(i, 'bookName')),
      author: author,
      artist: anchor || author || '番茄特约演播',
      intro: Shun.stripIntroPrefix(str(i, 'summary')),
      coverUrl: Shun.cleanCover(str(i, 'cover')),
      bookUrl: 'fq://yuntu/' + str(i, 'bookId'),
      status: '正版畅听' + (count > 0 ? ' · ' + count + ' 章' : '')
    };
  }

  function mapFreeXmlyBook(doc) {
    var tracks = int(doc, 'tracks_counts') || int(doc, 'tracks', 0);
    var cover = Shun.cleanCover(str(doc, 'cover_path') || str(doc, 'album_cover_path'));
    if (cover) cover = cover.split('!')[0] + '!op_type=3&columns=640&rows=640';
    var nick = str(doc, 'nickname').trim();
    return {
      title: Shun.cleanHtml(str(doc, 'title')),
      author: nick,
      artist: nick,
      intro: Shun.stripIntroPrefix(str(doc, 'custom_title') || str(doc, 'intro')),
      coverUrl: cover,
      bookUrl: 'fq://free_xmly/' + (str(doc, 'id') || str(doc, 'album_id')),
      status: (String(doc.is_finished) === '2' ? '完结' : '连载') + (tracks > 0 ? ' · ' + tracks + ' 章' : '')
    };
  }

  function mapFanqieOfficialBook(it) {
    var bid = str(it, 'book_id') || str(it, 'bookId');
    var title = Shun.cleanHtml(str(it, 'title') || str(it, 'book_name') || str(it, 'bookName'));
    if (!bid || !title) return null;
    var cat = Shun.cleanHtml(str(it, 'category'));
    var score = str(it, 'score');
    var statusParts = [];
    if (cat) statusParts.push(cat);
    if (score && score !== '0') statusParts.push(score + '分');
    var author = Shun.cleanHtml(str(it, 'author'));
    return {
      title: title,
      author: author,
      artist: author || '番茄畅听演播',
      intro: Shun.stripIntroPrefix(str(it, 'abstract')),
      coverUrl: Shun.cleanCover(str(it, 'thumb_url') || str(it, 'thumbUri')),
      bookUrl: 'fq://official/' + bid + '?title=' + encodeURIComponent(title),
      status: statusParts.join(' · ') || '番茄畅听'
    };
  }

  /** 多通道有声书并发搜索池：将 GET 通道并发拉取，大幅降低延迟 */
  function searchCombinedPool(host, keywords, page, includeOfficial) {
    var books = [];
    var seenTitle = {};
    var seenUrl = {};

    function pushBook(b, dedupByTitle) {
      if (!b || !b.title || !b.bookUrl) return;
      if (seenUrl[b.bookUrl]) return;
      var normTitle = b.title.replace(/[《》\s（）()【】\[\]]/g, '').toLowerCase();
      if (dedupByTitle && seenTitle[normTitle]) return;
      seenUrl[b.bookUrl] = true;
      seenTitle[normTitle] = true;
      books.push(b);
    }

    // 1. 听友有声引擎（POST，复用持久化可用网关）
    try {
      var ty = Shun.callTingyou(host, 'search', { keyword: keywords, page: page });
      if (ty) {
        items(ty, 'results').forEach(function (item) { pushBook(mapTingyouBook(item), false); });
      }
    } catch (e) { if (e && e.cancelled) throw e; }

    // 2. 并发拉取云图 + 喜马拉雅免费库（+ 可选番茄官方）
    var yuntuBase = Shun.yuntuCurrentBase(host);
    var getUrls = [
      yuntuBase + 'search/' + Shun.YUNTU_TOKEN + '/' + Shun.enc(keywords) + '?pageSize=20&pageNum=' + page,
      XMLY_FREE_SEARCH + '?core=album&kw=' + Shun.enc(keywords) +
        '&page=' + page + '&rows=20&spellchecker=true&condition=relation&device=android&version=9.0.75&paidFilter=true'
    ];
    if (includeOfficial) {
      var offset = (Math.max(1, page) - 1) * 10;
      getUrls.push(
        FQ_SEARCH_API + '?q=' + Shun.enc(keywords) + '&offset=' + offset +
          '&enter_from=inner_search&app_name=news_article&version_name=7.0.8&app_version=7.0.8' +
          '&channel=tt_huawei2019_yz&version_code=708&device_platform=android&aid=13&language=zh'
      );
    }

    var responses = [];
    try {
      responses = host.getStrings(getUrls, { headers: { 'User-Agent': FQ_APP_UA } }, getUrls.length) || [];
    } catch (e) {
      if (e && e.cancelled) throw e;
    }

    // 解析云图
    if (responses[0]) {
      try {
        items(parseJson(responses[0]), 'data.list').forEach(function (item) { pushBook(mapYuntuBook(item), false); });
      } catch (e) {}
    } else {
      // HTTPS 失败时通过 yuntuGetJson 自动回退 HTTP
      try {
        var ytFb = Shun.yuntuGetJson(host, 'search/' + Shun.YUNTU_TOKEN + '/' + Shun.enc(keywords) + '?pageSize=20&pageNum=' + page);
        items(ytFb, 'data.list').forEach(function (item) { pushBook(mapYuntuBook(item), false); });
      } catch (e) { if (e && e.cancelled) throw e; }
    }

    // 解析喜马拉雅免费库
    if (responses[1]) {
      try {
        items(parseJson(responses[1]), 'response.docs').forEach(function (doc) {
          if (doc.is_paid === false || doc.is_paid === 'false' || !doc.is_paid) {
            pushBook(mapFreeXmlyBook(doc), false);
          }
        });
      } catch (e) {}
    }

    // 解析番茄官方
    if (includeOfficial && responses[2]) {
      try {
        items(parseJson(responses[2]), 'data.ret_data').forEach(function (it) {
          var mapped = mapFanqieOfficialBook(it);
          if (mapped) pushBook(mapped, true);
        });
      } catch (e) {}
    }

    return books;
  }

  function loadEpisodesByTarget(host, bookUrl, loadEpisodes, loadFullPages) {
    // A. 听友免费有声引擎
    if (bookUrl.indexOf('fq://tingyou/') === 0) {
      var tyId = bookUrl.replace('fq://tingyou/', '');
      var album = {};
      var chJson = {};
      if (loadEpisodes) {
        var base = Shun.tingyouBaseUrl(host);
        var hdrs = Shun.tingyouHeaders(host);
        var pair = [];
        try {
          pair = host.getStrings([base + '/h5/listening/album/' + tyId, base + '/h5/listening/chapters/' + tyId], { headers: hdrs }, 2) || [];
        } catch (e) { if (e && e.cancelled) throw e; }
        try { album = pair[0] ? parseJson(pair[0]) : (Shun.callTingyou(host, 'album/' + tyId) || {}); } catch (e) { album = Shun.callTingyou(host, 'album/' + tyId) || {}; }
        try { chJson = pair[1] ? parseJson(pair[1]) : (Shun.callTingyou(host, 'chapters/' + tyId) || {}); } catch (e) { chJson = Shun.callTingyou(host, 'chapters/' + tyId) || {}; }
      } else {
        album = Shun.callTingyou(host, 'album/' + tyId) || {};
      }
      var detail = mapTingyouBook(album);
      detail.episodes = [];
      if (loadEpisodes) {
        detail.episodes = items(chJson, 'chapters').map(function (ch, idx) {
          var indexNum = ch.index !== undefined ? ch.index : (idx + 1);
          return {
            title: Shun.cleanChapterTitle(str(ch, 'title'), detail.title) || ('第 ' + (idx + 1) + ' 章'),
            url: 'fq://tingyou_play/' + tyId + '/' + indexNum,
            isFree: true
          };
        });
      }
      return detail;
    }

    // B. 云图正版直链引擎（补齐单书简介元数据 + 6 路并发拉取）
    if (bookUrl.indexOf('fq://yuntu/') === 0) {
      var ytId = bookUrl.replace('fq://yuntu/', '');
      var ytDetail = { episodes: [] };
      var firstJson = Shun.yuntuGetJson(host, 'getChapters/' + Shun.YUNTU_TOKEN + '/' + ytId + '/true/asc?pageSize=200&pageNum=1');
      var bookInfo = at(firstJson, 'data.book') || at(firstJson, 'data.bookInfo') || {};
      if (str(bookInfo, 'bookName')) ytDetail.title = Shun.cleanHtml(str(bookInfo, 'bookName'));
      if (str(bookInfo, 'cover')) ytDetail.coverUrl = Shun.cleanCover(str(bookInfo, 'cover'));
      if (str(bookInfo, 'anchorName') || str(bookInfo, 'authorName')) {
        ytDetail.artist = str(bookInfo, 'anchorName').trim() || str(bookInfo, 'authorName').trim();
      }
      if (str(bookInfo, 'summary')) ytDetail.intro = Shun.stripIntroPrefix(str(bookInfo, 'summary'));
      if (!loadEpisodes) return ytDetail;

      var pq = at(firstJson, 'data.pageQuery') || {};
      var totalPage = Math.min(50, int(pq, 'totalPage', 1));
      var rawList = items(pq, 'list');
      if (loadFullPages && totalPage > 1) {
        var ytBase = Shun.yuntuCurrentBase(host);
        var batchUrls = [];
        for (var p = 2; p <= totalPage; p++) {
          batchUrls.push(ytBase + 'getChapters/' + Shun.YUNTU_TOKEN + '/' + ytId + '/true/asc?pageSize=200&pageNum=' + p);
        }
        host.getStrings(batchUrls, {}, 6).forEach(function (t) {
          if (!t) return;
          try {
            var j = parseJson(t);
            rawList = rawList.concat(items(j, 'data.pageQuery.list'));
          } catch (e) {}
        });
      }
      ytDetail.episodes = rawList.map(function (item, idx) {
        return {
          title: Shun.cleanChapterTitle(str(item, 'name'), ytDetail.title || '') || ('第 ' + (idx + 1) + ' 章'),
          url: Shun.httpsUrl(str(item, 'audioUrl')),
          isFree: true
        };
      });
      return ytDetail;
    }

    // C. 喜马拉雅免费有声专辑（主备双接口容灾 + 6 路并发）
    if (bookUrl.indexOf('fq://free_xmly/') === 0) {
      var xmId = bookUrl.replace('fq://free_xmly/', '').replace(/[^0-9]/g, '');
      var detailXm = { episodes: [] };
      try {
        var info = at(host.getJson('https://www.ximalaya.com/revision/album/v1/simple?albumId=' + xmId, {
          desktop: true, headers: { Referer: 'https://www.ximalaya.com/' }
        }), 'data.albumPageMainInfo') || {};
        detailXm.title = Shun.cleanHtml(str(info, 'albumTitle'));
        detailXm.coverUrl = Shun.cleanCover(str(info, 'cover')) ? (Shun.cleanCover(str(info, 'cover')).split('!')[0] + '!op_type=3&columns=640&rows=640') : '';
        detailXm.artist = str(info, 'anchorName');
        detailXm.intro = Shun.stripIntroPrefix(str(info, 'richIntro') || str(info, 'shortIntro'));
      } catch (e) {}
      if (!loadEpisodes) return detailXm;

      var useBackup = false;
      function makeXmUrl(pg) {
        return useBackup
          ? ('https://mobile.ximalaya.com/mobile/others/ca/album/track/' + xmId + '/true/' + pg + '/200')
          : ('https://mobile.ximalaya.com/mobile/v1/album/track?albumId=' + xmId + '&pageSize=200&isAsc=true&device=android&pageId=' + pg);
      }
      function extractXm(j) {
        return useBackup ? (int(j, 'ret') === 0 ? j.tracks : null) : (int(j, 'ret') === 0 ? j.data : null);
      }

      var firstTrack = host.getJson(makeXmUrl(1));
      var dataObj = extractXm(firstTrack);
      if (!dataObj) {
        useBackup = true;
        dataObj = extractXm(host.getJson(makeXmUrl(1))) || {};
      }
      var maxPage = Math.min(50, int(dataObj, 'maxPageId', 1));
      var tracks = items(dataObj, 'list');
      if (loadFullPages && maxPage > 1) {
        var urls = [];
        for (var pg = 2; pg <= maxPage; pg++) urls.push(makeXmUrl(pg));
        host.getStrings(urls, {}, 6).forEach(function (txt) {
          if (!txt) return;
          try {
            var pd = extractXm(parseJson(txt));
            if (pd) tracks = tracks.concat(items(pd, 'list'));
          } catch (e) {}
        });
      }
      detailXm.episodes = tracks.map(function (t, idx) {
        var tid = str(t, 'trackId');
        var fallbackDirect = Shun.httpsUrl(str(t, 'playUrl64') || str(t, 'playPathAacv164') || str(t, 'playUrl32'));
        return {
          title: Shun.cleanChapterTitle(Shun.cleanHtml(str(t, 'title')), detailXm.title) || ('第 ' + (idx + 1) + ' 章'),
          url: tid ? ('fq://xmly_track/' + tid) : fallbackDirect,
          isFree: true
        };
      });
      return detailXm;
    }

    // D. 番茄官方条目：按书名并发匹配最佳有声直链
    var titleMatch = /[?&]title=([^&#]+)/.exec(bookUrl);
    var bookTitle = titleMatch ? decodeURIComponent(titleMatch[1]) : '';
    if (bookTitle) {
      var candidates = searchCombinedPool(host, bookTitle, 1, false);
      for (var c = 0; c < Math.min(3, candidates.length); c++) {
        try {
          var subDetail = loadEpisodesByTarget(host, candidates[c].bookUrl, loadEpisodes, loadFullPages);
          if (subDetail && subDetail.episodes && subDetail.episodes.length > 0) {
            return subDetail;
          }
        } catch (e) { if (e && e.cancelled) throw e; }
      }
    }
    throw new Error('该书暂未收录有声章节，请在搜索页选择其他演播版本');
  }

  registerSource({
    id: 'fanqie_changting_pro_v56',
    name: '番茄畅听',
    url: FQ_SITE + '/',
    group: '主力听书',
    description: '主力推荐 ⭐⭐⭐⭐⭐\n融合番茄官方热榜书库与多路免费有声直链引擎，支持多路并发搜索、章节并发秒载与免登录直连播放。',
    multipleEpisodePages: true,
    loginUrl: 'https://fanqienovel.com/',
    loginDesktop: true,

    checkLogin: function () {
      var ck = typeof this.host.cookies === 'function' ? String(this.host.cookies(FQ_SITE + '/') || '') : '';
      if (/(?:^|;\s*)(?:sessionid|sessionid_ss|sid_tt|uid_tt)=[a-zA-Z0-9]{8,}/.test(ck)) {
        return '番茄账号已登录';
      }
      throw new Error('还没有登录番茄畅听');
    },

    search: function (keywords, page) {
      var p = page || 1;
      var books = searchCombinedPool(this.host, keywords, p, true);
      return {
        books: books,
        totalPage: books.length >= 10 ? p + 1 : p
      };
    },

    categoryMenus: function () {
      var audioCats = [
        ['巅峰热榜', '修仙'],
        ['完本经典', '诡秘'],
        ['都市爽文', '都市'],
        ['玄幻修仙', '玄幻'],
        ['悬疑盗墓', '盗墓'],
        ['历史军事', '大明'],
        ['古风言情', '古风'],
        ['科幻末世', '科幻'],
        ['武侠仙侠', '武侠'],
        ['官场商战', '商战'],
        ['相声评书', '评书'],
        ['有声名著', '名著']
      ];
      var fqOfficialCats = [
        ['番茄都市', 'novel:1:都市'],
        ['番茄玄幻', 'novel:7:玄幻'],
        ['番茄悬疑', 'novel:10:悬疑'],
        ['番茄历史', 'novel:12:历史'],
        ['番茄现言', 'novel:3:现代言情'],
        ['番茄古言', 'novel:5:古代言情'],
        ['番茄科幻', 'novel:8:科幻末世'],
        ['番茄仙侠', 'novel:1140:东方仙侠'],
        ['番茄评书', 'opera:110:评书'],
        ['大案纪实', 'culture:562:大案纪实']
      ];
      return [
        {
          title: '有声剧场',
          tabs: audioCats.map(function (c) {
            return { title: c[0], url: 'fq://cat_audio/' + encodeURIComponent(c[1]) + '#1' };
          })
        },
        {
          title: '番茄分类榜',
          tabs: fqOfficialCats.map(function (c) {
            return { title: c[0], url: 'fq://cat_official/' + c[1] + '#1' };
          })
        }
      ];
    },

    categoryPage: function (url) {
      var host = this.host;
      var mOff = /^fq:\/\/cat_official\/([^:]+):(\d+):([^#]+)#(\d+)$/.exec(url);
      if (mOff) {
        var tag = mOff[1], catId = mOff[2], fallbackKw = mOff[3], page = parseInt(mOff[4], 10) || 1;
        var books = [];
        try {
          var offset = (page - 1) * 20;
          var apiUrl = FQ_CATEGORY_API + '?sdk_type=2&from_scene=201&parent_category_tag=' + tag +
            '&device_platform=android&os=android&aid=13&app_name=news_article_lite&version_code=160900' +
            '&language=zh&limit=20&offset=' + offset + '&category_id=' + catId;
          var json = host.getJson(apiUrl, { headers: { 'User-Agent': FQ_APP_UA } });
          var rawList = items(json, 'data.data');
          if (rawList.length === 0) rawList = items(json, 'data.book_info');
          if (rawList.length === 0) rawList = items(json, 'data');
          rawList.forEach(function (it) {
            var b = mapFanqieOfficialBook(it);
            if (b) books.push(b);
          });
        } catch (e) { if (e && e.cancelled) throw e; }
        if (books.length === 0) {
          books = searchCombinedPool(host, fallbackKw, page, true);
        }
        return {
          books: books,
          currentPage: page,
          totalPage: books.length > 0 ? page + 1 : page,
          nextUrl: books.length > 0 ? ('fq://cat_official/' + tag + ':' + catId + ':' + fallbackKw + '#' + (page + 1)) : null
        };
      }

      var mAud = /^fq:\/\/cat_audio\/([^#]+)#(\d+)$/.exec(url);
      var kw = mAud ? decodeURIComponent(mAud[1]) : '修仙';
      var pg = mAud ? (parseInt(mAud[2], 10) || 1) : 1;
      var list = searchCombinedPool(host, kw, pg, false);
      return {
        books: list,
        currentPage: pg,
        totalPage: list.length > 0 ? pg + 1 : pg,
        nextUrl: list.length > 0 ? ('fq://cat_audio/' + encodeURIComponent(kw) + '#' + (pg + 1)) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      return loadEpisodesByTarget(this.host, bookUrl, loadEpisodes !== false, loadFullPages !== false);
    },

    audio: function (url, quality) {
      if (/^https?:\/\//i.test(url)) {
        return Shun.httpsUrl(url);
      }
      if (url.indexOf('fq://tingyou_play/') === 0) {
        var parts = url.replace('fq://tingyou_play/', '').split('/');
        var res = Shun.callTingyou(this.host, 'play', {
          album_id: parts[0],
          chapter_idx: parseInt(parts[1] || '1', 10)
        });
        var playUrl = str(res, 'play_url');
        if (playUrl) return Shun.httpsUrl(playUrl);
        throw new Error(str(res, 'detail') || str(res, 'message') || '未能获取该章节播放地址');
      }
      if (url.indexOf('fq://xmly_track/') === 0) {
        return Shun.resolveXimalayaAudio(this.host, url, quality);
      }
      throw new Error('无法解析章节音频地址');
    }
  });
})();
