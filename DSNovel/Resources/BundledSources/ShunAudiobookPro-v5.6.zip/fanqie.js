// ---------- 番茄畅听（DSNovel 深度适配优化版） ----------
// 1. 聚合【番茄小说/畅听官方书城热榜与搜索接口 (fanqienovel.com / api.fanqiesdk.com)】与【三大免登录直链有声引擎（听友有声、云图有声、喜马拉雅免费库）】。
// 2. 搜索与分类既能浏览番茄官方实时榜单与海量网文，又能自动匹配高清真人多人有声剧章节直链，无需等待漫长的本地 CENC 逐样本解密，点击即播。
// 3. 严格校验真实账号登录状态（仅当存在真实登录 Cookie sessionid / sid_tt / uid_tt 时判定为已登录，杜绝匿名访客 ttwid 误报）。
(function () {
  var FQ_SITE = 'https://fanqienovel.com';
  var FQ_SEARCH_API = 'https://api.fanqiesdk.com/api/novel/channel/homepage/search/search/v1/';
  var FQ_CATEGORY_API = 'https://novel.snssdk.com/api/novel/channel/homepage/new_category/book_list/v1/';
  var FQ_APP_UA = 'com.ss.android.article.news/13400 (Linux; U; Android 13; zh_CN; Pixel 7; Build/TD1A.220804.031)';

  var TINGYOU_SITE = 'https://tingyou.fm';
  var TINGYOU_BASES = [
    'https://api-preview.toulaopao.cc/api',
    'https://appp.fdhtbz.cn/api',
    'https://laopaoaappi.oobyvy.vip/api'
  ];
  var YUNTU_API = 'http://open-service.yuntuys.com/api/w_ys/book/';
  var YUNTU_TOKEN = 'wechat:07955551-706c-4259-9aa0-db4627dfca57';
  var XMLY_FREE_SEARCH = 'https://search.ximalaya.com/front/v1';

  var workingTingyouBase = null;
  var sessionUUID = null;

  function callTingyou(host, path, body) {
    if (!sessionUUID) sessionUUID = (typeof host.uuid === 'function') ? host.uuid() : 'dsnovel-fq-session';
    var list = (workingTingyouBase ? [workingTingyouBase] : []).concat(TINGYOU_BASES);
    var tried = {};
    for (var i = 0; i < list.length; i++) {
      var base = list[i];
      if (!base || tried[base]) continue;
      tried[base] = true;
      try {
        var opts = {
          headers: {
            'Origin': TINGYOU_SITE,
            'Referer': TINGYOU_SITE + '/',
            'Accept': 'application/json',
            'x-listening-session': sessionUUID,
            'x-listening-timezone': 'Asia/Shanghai'
          }
        };
        if (body !== undefined) {
          opts.method = 'POST';
          opts.body = JSON.stringify(body);
          opts.contentType = 'application/json';
        }
        var txt = host.getString(base + '/h5/listening/' + path, opts);
        var json = parseJson(txt);
        if (json && !json.error) {
          workingTingyouBase = base;
          return json;
        }
      } catch (e) {
        if (e && e.cancelled) throw e;
      }
    }
    return null;
  }

  function mapTingyouBook(a) {
    var count = int(a, 'count', 0);
    return {
      title: str(a, 'title').trim(),
      author: str(a, 'author').trim(),
      artist: str(a, 'teller').trim() || '番茄精品有声',
      intro: Shun.cleanHtml(str(a, 'intro') || str(a, 'description') || str(a, 'synopsis')),
      coverUrl: Shun.httpsUrl(str(a, 'cover_url')),
      bookUrl: 'fq://tingyou/' + str(a, 'id'),
      status: (int(a, 'status', 0) === 0 ? '已完结' : '连载中') + (count > 0 ? ' · ' + count + ' 集' : '')
    };
  }

  function mapYuntuBook(i) {
    var count = int(i, 'chapters', 0);
    return {
      title: str(i, 'bookName').trim(),
      author: str(i, 'authorName').trim(),
      artist: str(i, 'anchorName').trim() || '番茄特约演播',
      intro: Shun.cleanHtml(str(i, 'summary')),
      coverUrl: Shun.httpsUrl(str(i, 'cover')),
      bookUrl: 'fq://yuntu/' + str(i, 'bookId'),
      status: '正版畅听' + (count > 0 ? ' · ' + count + ' 集' : '')
    };
  }

  function mapFreeXmlyBook(doc) {
    var tracks = int(doc, 'tracks_counts') || int(doc, 'tracks', 0);
    var cover = Shun.httpsUrl(str(doc, 'cover_path') || str(doc, 'album_cover_path'));
    if (cover && cover.indexOf('!') < 0) cover = cover + '!op_type=3&columns=290&rows=290';
    return {
      title: Shun.cleanHtml(str(doc, 'title')),
      author: str(doc, 'nickname').trim(),
      artist: str(doc, 'nickname').trim(),
      intro: Shun.cleanHtml(str(doc, 'custom_title') || str(doc, 'intro')),
      coverUrl: cover,
      bookUrl: 'fq://free_xmly/' + (str(doc, 'id') || str(doc, 'album_id')),
      status: (String(doc.is_finished) === '2' ? '完结' : '连载') + (tracks > 0 ? ' · ' + tracks + ' 集' : '')
    };
  }

  function mapFanqieOfficialBook(it) {
    var bid = str(it, 'book_id') || str(it, 'bookId');
    var title = Shun.cleanHtml(str(it, 'title') || str(it, 'book_name') || str(it, 'bookName'));
    if (!bid || !title) return null;
    var cat = Shun.cleanHtml(str(it, 'category'));
    var score = str(it, 'score');
    var statusParts = [];
    if (cat) statusParts.push(cat);
    if (score && score !== '0') statusParts.push(score + '分');
    return {
      title: title,
      author: Shun.cleanHtml(str(it, 'author')),
      artist: '番茄畅听AI/真人演播',
      intro: Shun.cleanHtml(str(it, 'abstract')),
      coverUrl: Shun.httpsUrl(str(it, 'thumb_url') || str(it, 'thumbUri')),
      bookUrl: 'fq://official/' + bid + '?title=' + encodeURIComponent(title),
      status: statusParts.join(' · ') || '番茄畅听'
    };
  }

  /** 多通道有声书搜索池：将有声直链源（听友 + 云图 + 喜马拉雅免费库）与番茄官方书库融合 */
  function searchCombinedPool(host, keywords, page, includeOfficial) {
    var books = [];
    var seenTitle = {};
    var seenUrl = {};

    function pushBook(b, dedupByTitle) {
      if (!b || !b.title || !b.bookUrl) return;
      if (seenUrl[b.bookUrl]) return;
      var normTitle = b.title.replace(/[《》\s（）()【】\[\]]/g, '').toLowerCase();
      if (dedupByTitle && seenTitle[normTitle]) return;
      seenUrl[b.bookUrl] = true;
      seenTitle[normTitle] = true;
      books.push(b);
    }

    // 1. 听友有声引擎（全集一次性章节 + 纯免费直链）
    var ty = callTingyou(host, 'search', { keyword: keywords, page: page });
    if (ty) {
      items(ty, 'results').forEach(function (item) { pushBook(mapTingyouBook(item), false); });
    }

    // 2. 云图正版有声直链引擎
    try {
      var ytUrl = YUNTU_API + 'search/' + YUNTU_TOKEN + '/' + Shun.enc(keywords) + '?pageSize=20&pageNum=' + page;
      var ytJson = host.getJson(ytUrl);
      items(ytJson, 'data.list').forEach(function (item) { pushBook(mapYuntuBook(item), false); });
    } catch (e) { if (e && e.cancelled) throw e; }

    // 3. 喜马拉雅免费有声专辑库（严格过滤 is_paid === false）
    try {
      var xmUrl = XMLY_FREE_SEARCH + '?core=album&kw=' + Shun.enc(keywords) +
        '&page=' + page + '&rows=20&spellchecker=true&condition=relation&device=android&version=9.0.75&paidFilter=true';
      var xmJson = host.getJson(xmUrl);
      items(xmJson, 'response.docs').forEach(function (doc) {
        if (doc.is_paid === false || doc.is_paid === 'false' || !doc.is_paid) {
          pushBook(mapFreeXmlyBook(doc), false);
        }
      });
    } catch (e) { if (e && e.cancelled) throw e; }

    // 4. 番茄小说官方搜索接口（补充番茄独家网文，点击时自动匹配最佳有声源）
    if (includeOfficial) {
      try {
        var offset = (Math.max(1, page) - 1) * 10;
        var fqUrl = FQ_SEARCH_API + '?q=' + Shun.enc(keywords) + '&offset=' + offset +
          '&enter_from=inner_search&app_name=news_article&version_name=7.0.8&app_version=7.0.8' +
          '&channel=tt_huawei2019_yz&version_code=708&device_platform=android&aid=13&language=zh';
        var fqJson = host.getJson(fqUrl, { headers: { 'User-Agent': FQ_APP_UA } });
        items(fqJson, 'data.ret_data').forEach(function (it) {
          var mapped = mapFanqieOfficialBook(it);
          if (mapped) pushBook(mapped, true);
        });
      } catch (e) { if (e && e.cancelled) throw e; }
    }

    return books;
  }

  /** 根据给定 URL 加载章节详情（支持听友、云图、喜马拉雅免费库及番茄官方自动穿透） */
  function loadEpisodesByTarget(host, bookUrl, loadEpisodes, loadFullPages) {
    // A. 听友免费有声引擎
    if (bookUrl.indexOf('fq://tingyou/') === 0) {
      var tyId = bookUrl.replace('fq://tingyou/', '');
      var album = callTingyou(host, 'album/' + tyId) || {};
      var detail = mapTingyouBook(album);
      detail.episodes = [];
      if (loadEpisodes) {
        var chJson = callTingyou(host, 'chapters/' + tyId) || {};
        detail.episodes = items(chJson, 'chapters').map(function (ch, idx) {
          var indexNum = ch.index !== undefined ? ch.index : (idx + 1);
          return {
            title: Shun.cleanChapterTitle(str(ch, 'title'), detail.title) || ('第 ' + (idx + 1) + ' 集'),
            url: 'fq://tingyou_play/' + tyId + '/' + indexNum,
            isFree: true
          };
        });
      }
      return detail;
    }

    // B. 云图正版直链引擎（6 路并发拉取全量章节）
    if (bookUrl.indexOf('fq://yuntu/') === 0) {
      var ytId = bookUrl.replace('fq://yuntu/', '');
      if (!loadEpisodes) return { episodes: [] };
      var firstUrl = YUNTU_API + 'getChapters/' + YUNTU_TOKEN + '/' + ytId + '/true/asc?pageSize=200&pageNum=1';
      var firstJson = host.getJson(firstUrl);
      var pq = at(firstJson, 'data.pageQuery') || {};
      var totalPage = Math.min(20, int(pq, 'totalPage', 1));
      var rawList = items(pq, 'list');
      if (loadFullPages && totalPage > 1) {
        var batchUrls = [];
        for (var p = 2; p <= totalPage; p++) {
          batchUrls.push(YUNTU_API + 'getChapters/' + YUNTU_TOKEN + '/' + ytId + '/true/asc?pageSize=200&pageNum=' + p);
        }
        host.getStrings(batchUrls, {}, 6).forEach(function (t) {
          if (!t) return;
          try {
            var j = parseJson(t);
            rawList = rawList.concat(items(j, 'data.pageQuery.list'));
          } catch (e) {}
        });
      }
      return {
        episodes: rawList.map(function (item, idx) {
          return {
            title: Shun.cleanChapterTitle(str(item, 'name'), '') || ('第 ' + (idx + 1) + ' 集'),
            url: Shun.httpsUrl(str(item, 'audioUrl')),
            isFree: true
          };
        })
      };
    }

    // C. 喜马拉雅免费有声专辑（6 路并发拉取全量章节）
    if (bookUrl.indexOf('fq://free_xmly/') === 0) {
      var xmId = bookUrl.replace('fq://free_xmly/', '').replace(/[^0-9]/g, '');
      var detailXm = { episodes: [] };
      try {
        var info = at(host.getJson('https://www.ximalaya.com/revision/album/v1/simple?albumId=' + xmId, {
          desktop: true, headers: { Referer: 'https://www.ximalaya.com/' }
        }), 'data.albumPageMainInfo') || {};
        detailXm.title = str(info, 'albumTitle');
        detailXm.artist = str(info, 'anchorName');
        detailXm.intro = Shun.cleanHtml(str(info, 'richIntro') || str(info, 'shortIntro'));
      } catch (e) {}
      if (!loadEpisodes) return detailXm;

      var baseTrackUrl = 'https://mobile.ximalaya.com/mobile/v1/album/track?albumId=' + xmId + '&pageSize=200&isAsc=true&device=android&pageId=';
      var firstTrack = host.getJson(baseTrackUrl + '1');
      var dataObj = at(firstTrack, 'data') || {};
      var maxPage = Math.min(20, int(dataObj, 'maxPageId', 1));
      var tracks = items(dataObj, 'list');
      if (loadFullPages && maxPage > 1) {
        var urls = [];
        for (var pg = 2; pg <= maxPage; pg++) urls.push(baseTrackUrl + pg);
        host.getStrings(urls, {}, 6).forEach(function (txt) {
          if (!txt) return;
          try {
            tracks = tracks.concat(items(parseJson(txt), 'data.list'));
          } catch (e) {}
        });
      }
      detailXm.episodes = tracks.map(function (t, idx) {
        var tid = str(t, 'trackId');
        var fallbackDirect = Shun.httpsUrl(str(t, 'playUrl64') || str(t, 'playPathAacv164') || str(t, 'playUrl32'));
        return {
          title: Shun.cleanChapterTitle(str(t, 'title'), detailXm.title) || ('第 ' + (idx + 1) + ' 集'),
          url: tid ? ('fq://xmly_track/' + tid) : fallbackDirect,
          isFree: true
        };
      });
      return detailXm;
    }

    // D. 番茄官方条目（fq://official/{bookId}?title=...）：自动按书名匹配有声直链引擎章节
    var titleMatch = /[?&]title=([^&#]+)/.exec(bookUrl);
    var bookTitle = titleMatch ? decodeURIComponent(titleMatch[1]) : '';
    if (bookTitle) {
      var candidates = searchCombinedPool(host, bookTitle, 1, false);
      for (var c = 0; c < Math.min(3, candidates.length); c++) {
        try {
          var subDetail = loadEpisodesByTarget(host, candidates[c].bookUrl, loadEpisodes, loadFullPages);
          if (subDetail && subDetail.episodes && subDetail.episodes.length > 0) {
            return subDetail;
          }
        } catch (e) { if (e && e.cancelled) throw e; }
      }
    }
    throw new Error('该书暂无有声朗读音源，请尝试在搜索页切换其他同名有声版本');
  }

  registerSource({
    id: 'fanqie_changting_pro_v56',
    name: '番茄畅听',
    url: FQ_SITE + '/',
    group: '主力听书',
    description: '主力推荐 ⭐⭐⭐⭐⭐\n融合番茄小说/畅听官方热榜书库与多路正版免费有声直链引擎，涵盖都市爽文、玄幻修仙、悬疑盗墓、古风言情、历史军事等全品类，支持章节并发秒载与免登录直连播放。',
    multipleEpisodePages: true,
    loginUrl: 'https://fanqienovel.com/',
    loginDesktop: true,

    // 严格校验番茄真实登录状态（仅当存在真实账号 Cookie 时返回已登录，绝不因匿名访客 ttwid 误判）
    checkLogin: function () {
      var ck = typeof this.host.cookies === 'function' ? String(this.host.cookies(FQ_SITE + '/') || '') : '';
      if (/(?:^|;\s*)(?:sessionid|sessionid_ss|sid_tt|uid_tt)=[a-zA-Z0-9]{8,}/.test(ck)) {
        return '番茄账号已登录';
      }
      throw new Error('还没有登录番茄畅听');
    },

    search: function (keywords, page) {
      var p = page || 1;
      var books = searchCombinedPool(this.host, keywords, p, true);
      return {
        books: books,
        totalPage: books.length >= 10 ? p + 1 : p
      };
    },

    categoryMenus: function () {
      var audioCats = [
        ['巅峰热榜', '凡人修仙传'],
        ['完本经典', '诡秘之主'],
        ['都市爽文', '都市神医'],
        ['玄幻修仙', '剑来'],
        ['悬疑盗墓', '盗墓笔记'],
        ['历史军事', '大明'],
        ['古风言情', '庶女攻略'],
        ['科幻末世', '吞噬星空'],
        ['武侠仙侠', '雪中悍刀行'],
        ['官场商战', '官场'],
        ['相声评书', '单田芳'],
        ['有声名著', '三体']
      ];
      var fqOfficialCats = [
        ['番茄都市', 'novel:1:都市'],
        ['番茄玄幻', 'novel:7:玄幻'],
        ['番茄悬疑', 'novel:10:悬疑'],
        ['番茄历史', 'novel:12:历史'],
        ['番茄现言', 'novel:3:现代言情'],
        ['番茄古言', 'novel:5:古代言情'],
        ['番茄科幻', 'novel:8:科幻末世'],
        ['番茄仙侠', 'novel:1140:东方仙侠'],
        ['番茄评书', 'opera:110:评书'],
        ['大案纪实', 'culture:562:大案纪实']
      ];
      return [
        {
          title: '有声剧场',
          tabs: audioCats.map(function (c) {
            return { title: c[0], url: 'fq://cat_audio/' + encodeURIComponent(c[1]) + '#1' };
          })
        },
        {
          title: '番茄分类榜',
          tabs: fqOfficialCats.map(function (c) {
            return { title: c[0], url: 'fq://cat_official/' + c[1] + '#1' };
          })
        }
      ];
    },

    categoryPage: function (url) {
      var host = this.host;
      // 1. 番茄官方分类接口 + 有声直链自动补充
      var mOff = /^fq:\/\/cat_official\/([^:]+):(\d+):([^#]+)#(\d+)$/.exec(url);
      if (mOff) {
        var tag = mOff[1], catId = mOff[2], fallbackKw = mOff[3], page = parseInt(mOff[4], 10) || 1;
        var books = [];
        try {
          var offset = (page - 1) * 20;
          var apiUrl = FQ_CATEGORY_API + '?sdk_type=2&from_scene=201&parent_category_tag=' + tag +
            '&device_platform=android&os=android&aid=13&app_name=news_article_lite&version_code=160900' +
            '&language=zh&limit=20&offset=' + offset + '&category_id=' + catId;
          var json = host.getJson(apiUrl, { headers: { 'User-Agent': FQ_APP_UA } });
          var rawList = items(json, 'data.data') || items(json, 'data.book_info') || items(json, 'data');
          rawList.forEach(function (it) {
            var b = mapFanqieOfficialBook(it);
            if (b) books.push(b);
          });
        } catch (e) { if (e && e.cancelled) throw e; }
        if (books.length === 0) {
          books = searchCombinedPool(host, fallbackKw, page, true);
        }
        return {
          books: books,
          currentPage: page,
          totalPage: books.length > 0 ? page + 1 : page,
          nextUrl: books.length > 0 ? ('fq://cat_official/' + tag + ':' + catId + ':' + fallbackKw + '#' + (page + 1)) : null
        };
      }

      // 2. 有声剧场分类
      var mAud = /^fq:\/\/cat_audio\/([^#]+)#(\d+)$/.exec(url);
      var kw = mAud ? decodeURIComponent(mAud[1]) : '凡人修仙传';
      var pg = mAud ? (parseInt(mAud[2], 10) || 1) : 1;
      var list = searchCombinedPool(host, kw, pg, false);
      return {
        books: list,
        currentPage: pg,
        totalPage: list.length > 0 ? pg + 1 : pg,
        nextUrl: list.length > 0 ? ('fq://cat_audio/' + encodeURIComponent(kw) + '#' + (pg + 1)) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      return loadEpisodesByTarget(this.host, bookUrl, loadEpisodes !== false, loadFullPages !== false);
    },

    audio: function (url, quality) {
      if (/^https?:\/\//i.test(url)) {
        return url;
      }
      if (url.indexOf('fq://tingyou_play/') === 0) {
        var parts = url.replace('fq://tingyou_play/', '').split('/');
        var res = callTingyou(this.host, 'play', {
          album_id: parts[0],
          chapter_idx: parseInt(parts[1] || '1', 10)
        });
        var playUrl = str(res, 'play_url');
        if (playUrl) return Shun.httpsUrl(playUrl);
        throw new Error(str(res, 'detail') || str(res, 'message') || '未能获取该章节播放地址');
      }
      if (url.indexOf('fq://xmly_track/') === 0) {
        var tid = url.replace('fq://xmly_track/', '');
        var targetQuality = String(quality || 'M4A_128').toUpperCase();
        var priorityMap = {
          'M4A_24':  ['M4A_24', 'MP3_32', 'M4A_64', 'MP3_64', 'M4A_128'],
          'M4A_64':  ['M4A_64', 'MP3_64', 'M4A_24', 'MP3_32', 'M4A_128'],
          'M4A_128': ['M4A_128', 'M4A_64', 'MP3_64', 'MP3_32', 'M4A_24']
        };
        var order = priorityMap[targetQuality] || priorityMap['M4A_128'];
        var webJson = this.host.getJson('https://www.ximalaya.com/mobile-playpage/track/v3/baseInfo/' + Date.now() +
          '?device=web&trackId=' + tid + '&trackQualityLevel=2', {
          desktop: true, headers: { Referer: 'https://www.ximalaya.com/' }
        });
        var list = items(webJson, 'trackInfo.playUrlList');
        if (list.length > 0) {
          var pick = null;
          for (var i = 0; i < order.length && !pick; i++) {
            for (var j = 0; j < list.length; j++) {
              if (str(list[j], 'type').toUpperCase() === order[i]) {
                pick = list[j];
                break;
              }
            }
          }
          if (!pick) pick = list[0];
          var decrypted = this.host.aesEcbDecrypt(str(pick, 'url'), 'aaad3e4fd540b0f79dca95606e72bf93');
          if (decrypted && decrypted.indexOf('http') === 0) return decrypted;
        }
        var info = this.host.getJson('https://mobile.ximalaya.com/mobile/playpage/track/v3/baseInfo/' + Date.now() + '?device=iPhone&trackId=' + tid);
        var ti = at(info, 'trackInfo') || {};
        var fbChain;
        if (targetQuality === 'M4A_24') {
          fbChain = str(ti, 'playPathAacv224') || str(ti, 'playUrl32') || str(ti, 'playPathAacv164') || str(ti, 'playUrl64');
        } else if (targetQuality === 'M4A_64') {
          fbChain = str(ti, 'playPathAacv164') || str(ti, 'playUrl64') || str(ti, 'playPathAacv224') || str(ti, 'playUrl32');
        } else {
          fbChain = str(ti, 'playPathHq') || str(ti, 'playPathAacv164') || str(ti, 'playUrl64') || str(ti, 'playUrl32');
        }
        var direct = Shun.httpsUrl(fbChain);
        if (direct) return direct;
      }
      throw new Error('无法解析章节音频地址');
    }
  });
})();
