// ---------- 喜马拉雅（DSNovel v5.6.4 深度适配优化版） ----------
(function () {
  var WEB = 'https://www.ximalaya.com';
  var PAGE_SIZE = 200;
  var CHANNELS = ['youshengshu', 'guangbojv', 'xiangsheng', 'ertong', 'lishi', 'renwen', 'xiqu', 'qinggan'];
  var MENU_CACHE_KEY = 'xmly_cat_menus_v2';
  var MENU_CACHE_TTL = 86400; // 24 小时

  function web(host, url) {
    return host.getJson(url, { desktop: true, headers: { Referer: WEB + '/' } });
  }

  function cover(u) {
    var clean = Shun.cleanCover(u);
    if (!clean) return '';
    return clean.split('!')[0] + '!op_type=3&columns=640&rows=640';
  }

  function loggedIn(host) {
    return typeof host.cookies === 'function' && /(^|;\s*)1&_token=/.test(String(host.cookies(WEB + '/') || ''));
  }

  function albumUrl(id) { return WEB + '/album/' + id; }
  function albumId(url) { return (/album\/(\d+)/.exec(url) || [])[1] || ''; }
  function finished(v) { return String(v) === '2' ? '完结' : '连载'; }

  registerSource({
    id: '6e2b9c4d8a1f4d37b5c0e73a9f1d2b64',
    name: '喜马拉雅',
    url: WEB + '/',
    group: '主力听书',
    description: '主力推荐 ⭐⭐⭐⭐⭐\n喜马拉雅有声书、多人有声剧、广播剧、相声评书、历史人文。免费内容免登录直听；VIP 与已购内容在书源管理页登录账号后即可收听全本。',
    multipleEpisodePages: true,
    loginUrl: 'https://m.ximalaya.com/login',
    loginDesktop: false,

    checkLogin: function () {
      var json = web(this.host, WEB + '/revision/main/getCurrentUser');
      if (int(json, 'ret') !== 200 || !json.data) throw new Error('还没有登录喜马拉雅');
      return str(json, 'data.nickname') || str(json, 'data.nickName') || '喜马拉雅会员';
    },

    search: function (keywords, page) {
      var host = this.host, kw = String(keywords || '').trim();
      if (loggedIn(host)) {
        try {
          var album = at(web(host, WEB + '/revision/search/main?core=album&kw=' + encodeURIComponent(kw) + '&page=' + page +
            '&spellchecker=true&rows=20&condition=relation&device=iPhone&fq=&paidFilter=false'), 'data.album');
          var found = items(album, 'docs').filter(function (d) { return str(d, 'albumId'); }).map(function (d) {
            return {
              bookUrl: albumUrl(str(d, 'albumId')),
              title: Shun.cleanHtml(str(d, 'title')),
              coverUrl: cover(str(d, 'coverPath')),
              artist: str(d, 'nickname'),
              intro: Shun.stripIntroPrefix(str(d, 'customTitle') || str(d, 'intro')),
              status: finished(d.isFinished) + ' · ' + int(d, 'tracksCount') + ' 章' + (d.isPaid ? ' · VIP/付费' : '')
            };
          });
          if (found.length > 0) return { books: found, totalPage: Math.max(page, int(album, 'totalPage', page)) };
        } catch (e) {
          if (e && e.cancelled) throw e;
        }
      }

      function oldSearch(word, p) {
        var r = host.getJson('https://search.ximalaya.com/front/v1?core=album&kw=' + encodeURIComponent(word) + '&page=' + p +
          '&rows=20&spellchecker=true&condition=relation&device=android&version=9.0.75&paidFilter=false').response;
        return {
          totalPage: int(r, 'totalPage', p),
          books: items(r, 'docs').map(function (d) {
            return {
              bookUrl: albumUrl(str(d, 'id')),
              title: Shun.cleanHtml(str(d, 'title')),
              coverUrl: cover(str(d, 'cover_path')),
              artist: str(d, 'nickname'),
              intro: Shun.stripIntroPrefix(str(d, 'custom_title') || str(d, 'intro')),
              status: finished(d.is_finished) + ' · ' + int(d, 'tracks') + ' 章' + (d.is_paid ? ' · VIP/付费' : '')
            };
          })
        };
      }

      var result = oldSearch(kw, page), books = result.books;
      // 最多补搜 1 次截断词，兼顾召回与全局搜索速度
      if (page === 1 && books.length < 3 && kw.length >= 4 && kw.indexOf(' ') < 0) {
        var seen = {};
        books.forEach(function (b) { seen[b.bookUrl] = true; });
        try {
          oldSearch(kw.substring(0, kw.length - 1), 1).books.forEach(function (b) {
            if (!seen[b.bookUrl]) { seen[b.bookUrl] = true; books.push(b); }
          });
        } catch (e) { if (e && e.cancelled) throw e; }
      }
      return { books: books, totalPage: Math.max(page, result.totalPage) };
    },

    categoryMenus: function () {
      var cached = Shun.readJsonCache(this.host, MENU_CACHE_KEY, MENU_CACHE_TTL);
      if (Array.isArray(cached) && cached.length > 0) return cached;

      var menus = [], groups = items(web(this.host, WEB + '/revision/category/allCategoryInfo'), 'data');
      var found = {};
      groups.forEach(function (g) {
        items(g, 'categories').forEach(function (c) { found[str(c, 'pinyin')] = c; });
      });
      CHANNELS.forEach(function (pinyin) {
        var c = found[pinyin];
        if (!c) return;
        var tabs = [{ title: '全部', url: 'xm-cat:' + pinyin + ':#1' }];
        items(c, 'subcategories').forEach(function (s) {
          if (str(s, 'code')) tabs.push({ title: str(s, 'displayValue'), url: 'xm-cat:' + pinyin + ':' + str(s, 'code') + '#1' });
        });
        menus.push({ title: str(c, 'displayName'), tabs: tabs });
      });
      if (menus.length > 0) Shun.writeJsonCache(this.host, MENU_CACHE_KEY, menus);
      return menus;
    },

    categoryPage: function (url) {
      var m = /^xm-cat:([^:]*):([^#]*)#(\d+)$/.exec(url);
      var page = parseInt(m[3], 10), perPage = 30;
      var data = web(this.host, WEB + '/revision/category/queryCategoryPageAlbums?category=' + m[1] + '&subcategory=' + m[2] +
        '&meta=&sort=0&page=' + page + '&perPage=' + perPage).data;
      var books = items(data, 'albums').map(function (a) {
        return {
          bookUrl: albumUrl(str(a, 'albumId')),
          title: Shun.cleanHtml(str(a, 'title')),
          coverUrl: cover(str(a, 'coverPath')),
          artist: str(a, 'anchorName'),
          intro: Shun.stripIntroPrefix(str(a, 'intro') || str(a, 'customTitle')),
          status: finished(a.isFinished) + ' · ' + int(a, 'trackCount') + ' 章' + (a.isPaid ? ' · VIP/付费' : '')
        };
      });
      var total = Math.min(50, Math.ceil(int(data, 'total') / perPage));
      return {
        books: books,
        currentPage: page,
        totalPage: Math.max(total, page),
        nextUrl: books.length > 0 && page < total ? 'xm-cat:' + m[1] + ':' + m[2] + '#' + (page + 1) : null
      };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, id = albumId(bookUrl);
      var detail = { episodes: [] };
      try {
        var info = at(web(host, WEB + '/revision/album/v1/simple?albumId=' + id), 'data.albumPageMainInfo') || {};
        detail.title = Shun.cleanHtml(str(info, 'albumTitle'));
        detail.coverUrl = cover(str(info, 'cover'));
        detail.artist = str(info, 'anchorName');
        detail.intro = Shun.stripIntroPrefix(str(info, 'richIntro') || str(info, 'shortIntro'));
        detail.status = finished(info.isFinished);
      } catch (e) {
        if (e && e.cancelled) throw e;
      }
      if (!loadEpisodes) return detail;

      var useBackup = false;
      function makePageUrl(p) {
        return useBackup
          ? ('https://mobile.ximalaya.com/mobile/others/ca/album/track/' + id + '/true/' + p + '/' + PAGE_SIZE)
          : ('https://mobile.ximalaya.com/mobile/v1/album/track?albumId=' + id + '&pageId=' + p + '&pageSize=' + PAGE_SIZE + '&isAsc=true&device=android');
      }

      function extractPageData(json) {
        if (!useBackup) {
          return int(json, 'ret') === 0 ? json.data : null;
        }
        return (int(json, 'ret') === 0 && json.tracks) ? json.tracks : null;
      }

      function appendTracks(data) {
        items(data, 'list').forEach(function (t, idx) {
          var cleaned = Shun.cleanChapterTitle(Shun.cleanHtml(str(t, 'title')), detail.title);
          detail.episodes.push({
            title: cleaned || ('第 ' + (detail.episodes.length + 1) + ' 章'),
            url: 'xm:' + str(t, 'trackId'),
            isFree: !t.isPaid || !!t.isFree || !!t.isAuthorized
          });
        });
      }

      var firstJson = host.getJson(makePageUrl(1));
      var firstData = extractPageData(firstJson);
      if (!firstData) {
        var reason = str(firstJson, 'msg');
        useBackup = true;
        var backupJson = host.getJson(makePageUrl(1));
        firstData = extractPageData(backupJson);
        if (!firstData) {
          throw new Error('喜马拉雅：' + (reason || str(backupJson, 'msg') || '获取章节列表失败'));
        }
      }

      appendTracks(firstData);
      var maxPage = Math.min(500, int(firstData, 'maxPageId', 1));
      if (!loadFullPages || maxPage <= 1) return detail;

      try {
        var urls = [];
        for (var p = 2; p <= maxPage; p++) urls.push(makePageUrl(p));
        for (var i = 0; i < urls.length; i += 6) {
          var batch = urls.slice(i, i + 6);
          host.progress(Math.min(i + batch.length + 1, maxPage) + ' / ' + maxPage);
          var texts = host.getStrings(batch, {}, 6);
          texts.forEach(function (txt) {
            if (!txt) return;
            try {
              var pageData = extractPageData(parseJson(txt));
              if (pageData) appendTracks(pageData);
            } catch (e) {}
          });
        }
      } finally {
        host.progress(null);
      }
      return detail;
    },

    audio: function (url, quality) {
      return Shun.resolveXimalayaAudio(this.host, url, quality);
    }
  });
})();
